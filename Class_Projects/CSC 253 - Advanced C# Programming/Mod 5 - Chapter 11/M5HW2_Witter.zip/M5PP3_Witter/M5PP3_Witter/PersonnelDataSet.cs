﻿namespace M5PP3_Witter
{


    partial class PersonnelDataSet
    {
    }
}

namespace M5PP3_Witter.PersonnelDataSetTableAdapters {
    
    
    public partial class EmployeeTableAdapter {
    }
}
