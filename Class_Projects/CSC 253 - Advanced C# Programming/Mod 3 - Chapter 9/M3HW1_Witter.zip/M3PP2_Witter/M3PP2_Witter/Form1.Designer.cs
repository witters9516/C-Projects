﻿namespace M3PP2_Witter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.carSpeedLabel = new System.Windows.Forms.Label();
            this.CarMakeLabel = new System.Windows.Forms.Label();
            this.carYearLabel = new System.Windows.Forms.Label();
            this.output3Label = new System.Windows.Forms.Label();
            this.output2Label = new System.Windows.Forms.Label();
            this.output1Label = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.createCarButton = new System.Windows.Forms.Button();
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.input3Label = new System.Windows.Forms.Label();
            this.input2Label = new System.Windows.Forms.Label();
            this.input1Label = new System.Windows.Forms.Label();
            this.speedListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // carSpeedLabel
            // 
            this.carSpeedLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carSpeedLabel.Location = new System.Drawing.Point(77, 205);
            this.carSpeedLabel.Name = "carSpeedLabel";
            this.carSpeedLabel.Size = new System.Drawing.Size(108, 26);
            this.carSpeedLabel.TabIndex = 27;
            this.carSpeedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CarMakeLabel
            // 
            this.CarMakeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CarMakeLabel.Location = new System.Drawing.Point(77, 169);
            this.CarMakeLabel.Name = "CarMakeLabel";
            this.CarMakeLabel.Size = new System.Drawing.Size(108, 26);
            this.CarMakeLabel.TabIndex = 26;
            this.CarMakeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // carYearLabel
            // 
            this.carYearLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carYearLabel.Location = new System.Drawing.Point(77, 136);
            this.carYearLabel.Name = "carYearLabel";
            this.carYearLabel.Size = new System.Drawing.Size(108, 26);
            this.carYearLabel.TabIndex = 25;
            this.carYearLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // output3Label
            // 
            this.output3Label.AutoSize = true;
            this.output3Label.Location = new System.Drawing.Point(12, 212);
            this.output3Label.Name = "output3Label";
            this.output3Label.Size = new System.Drawing.Size(60, 13);
            this.output3Label.TabIndex = 24;
            this.output3Label.Text = "Car Speed:";
            // 
            // output2Label
            // 
            this.output2Label.AutoSize = true;
            this.output2Label.Location = new System.Drawing.Point(12, 176);
            this.output2Label.Name = "output2Label";
            this.output2Label.Size = new System.Drawing.Size(56, 13);
            this.output2Label.TabIndex = 23;
            this.output2Label.Text = "Car Make:";
            // 
            // output1Label
            // 
            this.output1Label.AutoSize = true;
            this.output1Label.Location = new System.Drawing.Point(12, 143);
            this.output1Label.Name = "output1Label";
            this.output1Label.Size = new System.Drawing.Size(51, 13);
            this.output1Label.TabIndex = 22;
            this.output1Label.Text = "Car Year:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(110, 100);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 21;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // createCarButton
            // 
            this.createCarButton.Location = new System.Drawing.Point(15, 100);
            this.createCarButton.Name = "createCarButton";
            this.createCarButton.Size = new System.Drawing.Size(75, 23);
            this.createCarButton.TabIndex = 20;
            this.createCarButton.Text = "Create Car";
            this.createCarButton.UseVisualStyleBackColor = true;
            this.createCarButton.Click += new System.EventHandler(this.createCarButton_Click);
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(85, 69);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 20);
            this.speedTextBox.TabIndex = 19;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(85, 43);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 20);
            this.makeTextBox.TabIndex = 18;
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(85, 17);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 20);
            this.yearTextBox.TabIndex = 17;
            // 
            // input3Label
            // 
            this.input3Label.AutoSize = true;
            this.input3Label.Location = new System.Drawing.Point(12, 72);
            this.input3Label.Name = "input3Label";
            this.input3Label.Size = new System.Drawing.Size(60, 13);
            this.input3Label.TabIndex = 16;
            this.input3Label.Text = "Car Speed:";
            // 
            // input2Label
            // 
            this.input2Label.AutoSize = true;
            this.input2Label.Location = new System.Drawing.Point(12, 46);
            this.input2Label.Name = "input2Label";
            this.input2Label.Size = new System.Drawing.Size(56, 13);
            this.input2Label.TabIndex = 15;
            this.input2Label.Text = "Car Make:";
            // 
            // input1Label
            // 
            this.input1Label.AutoSize = true;
            this.input1Label.Location = new System.Drawing.Point(12, 20);
            this.input1Label.Name = "input1Label";
            this.input1Label.Size = new System.Drawing.Size(51, 13);
            this.input1Label.TabIndex = 14;
            this.input1Label.Text = "Car Year:";
            // 
            // speedListBox
            // 
            this.speedListBox.FormattingEnabled = true;
            this.speedListBox.Location = new System.Drawing.Point(15, 247);
            this.speedListBox.Name = "speedListBox";
            this.speedListBox.Size = new System.Drawing.Size(170, 186);
            this.speedListBox.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(205, 456);
            this.Controls.Add(this.speedListBox);
            this.Controls.Add(this.carSpeedLabel);
            this.Controls.Add(this.CarMakeLabel);
            this.Controls.Add(this.carYearLabel);
            this.Controls.Add(this.output3Label);
            this.Controls.Add(this.output2Label);
            this.Controls.Add(this.output1Label);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createCarButton);
            this.Controls.Add(this.speedTextBox);
            this.Controls.Add(this.makeTextBox);
            this.Controls.Add(this.yearTextBox);
            this.Controls.Add(this.input3Label);
            this.Controls.Add(this.input2Label);
            this.Controls.Add(this.input1Label);
            this.Name = "Form1";
            this.Text = "Car";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label carSpeedLabel;
        private System.Windows.Forms.Label CarMakeLabel;
        private System.Windows.Forms.Label carYearLabel;
        private System.Windows.Forms.Label output3Label;
        private System.Windows.Forms.Label output2Label;
        private System.Windows.Forms.Label output1Label;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createCarButton;
        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.Label input3Label;
        private System.Windows.Forms.Label input2Label;
        private System.Windows.Forms.Label input1Label;
        private System.Windows.Forms.ListBox speedListBox;
    }
}

