﻿namespace M4PP1_Witter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.descPanelLabel = new System.Windows.Forms.Label();
            this.pwNameTextBox = new System.Windows.Forms.TextBox();
            this.pwEmployeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.pwShiftNumTextBox = new System.Windows.Forms.TextBox();
            this.pwHPRTextBox = new System.Windows.Forms.TextBox();
            this.inputDesc1Label = new System.Windows.Forms.Label();
            this.inputDesc2Label = new System.Windows.Forms.Label();
            this.inputDesc3Label = new System.Windows.Forms.Label();
            this.inputDesc4Label = new System.Windows.Forms.Label();
            this.createPWButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pwHPRLabel = new System.Windows.Forms.Label();
            this.pwShiftNumLabel = new System.Windows.Forms.Label();
            this.pwEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.pwNameLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Controls.Add(this.createPWButton);
            this.panel1.Controls.Add(this.inputDesc4Label);
            this.panel1.Controls.Add(this.inputDesc3Label);
            this.panel1.Controls.Add(this.inputDesc2Label);
            this.panel1.Controls.Add(this.inputDesc1Label);
            this.panel1.Controls.Add(this.pwHPRTextBox);
            this.panel1.Controls.Add(this.pwShiftNumTextBox);
            this.panel1.Controls.Add(this.pwEmployeeNumberTextBox);
            this.panel1.Controls.Add(this.pwNameTextBox);
            this.panel1.Controls.Add(this.descPanelLabel);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 220);
            this.panel1.TabIndex = 0;
            // 
            // descPanelLabel
            // 
            this.descPanelLabel.AutoSize = true;
            this.descPanelLabel.Location = new System.Drawing.Point(12, 10);
            this.descPanelLabel.Name = "descPanelLabel";
            this.descPanelLabel.Size = new System.Drawing.Size(96, 13);
            this.descPanelLabel.TabIndex = 0;
            this.descPanelLabel.Text = "Production Woker:";
            // 
            // pwNameTextBox
            // 
            this.pwNameTextBox.Location = new System.Drawing.Point(186, 43);
            this.pwNameTextBox.Name = "pwNameTextBox";
            this.pwNameTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwNameTextBox.TabIndex = 1;
            // 
            // pwEmployeeNumberTextBox
            // 
            this.pwEmployeeNumberTextBox.Location = new System.Drawing.Point(186, 69);
            this.pwEmployeeNumberTextBox.Name = "pwEmployeeNumberTextBox";
            this.pwEmployeeNumberTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwEmployeeNumberTextBox.TabIndex = 2;
            // 
            // pwShiftNumTextBox
            // 
            this.pwShiftNumTextBox.Location = new System.Drawing.Point(186, 95);
            this.pwShiftNumTextBox.Name = "pwShiftNumTextBox";
            this.pwShiftNumTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwShiftNumTextBox.TabIndex = 3;
            // 
            // pwHPRTextBox
            // 
            this.pwHPRTextBox.Location = new System.Drawing.Point(186, 121);
            this.pwHPRTextBox.Name = "pwHPRTextBox";
            this.pwHPRTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwHPRTextBox.TabIndex = 4;
            // 
            // inputDesc1Label
            // 
            this.inputDesc1Label.AutoSize = true;
            this.inputDesc1Label.Location = new System.Drawing.Point(12, 46);
            this.inputDesc1Label.Name = "inputDesc1Label";
            this.inputDesc1Label.Size = new System.Drawing.Size(127, 13);
            this.inputDesc1Label.TabIndex = 6;
            this.inputDesc1Label.Text = "Production Woker Name:";
            // 
            // inputDesc2Label
            // 
            this.inputDesc2Label.AutoSize = true;
            this.inputDesc2Label.Location = new System.Drawing.Point(12, 72);
            this.inputDesc2Label.Name = "inputDesc2Label";
            this.inputDesc2Label.Size = new System.Drawing.Size(136, 13);
            this.inputDesc2Label.TabIndex = 7;
            this.inputDesc2Label.Text = "Production Woker Number:";
            // 
            // inputDesc3Label
            // 
            this.inputDesc3Label.AutoSize = true;
            this.inputDesc3Label.Location = new System.Drawing.Point(12, 98);
            this.inputDesc3Label.Name = "inputDesc3Label";
            this.inputDesc3Label.Size = new System.Drawing.Size(160, 13);
            this.inputDesc3Label.TabIndex = 8;
            this.inputDesc3Label.Text = "Production Woker Shift Number:";
            // 
            // inputDesc4Label
            // 
            this.inputDesc4Label.AutoSize = true;
            this.inputDesc4Label.Location = new System.Drawing.Point(12, 124);
            this.inputDesc4Label.Name = "inputDesc4Label";
            this.inputDesc4Label.Size = new System.Drawing.Size(87, 13);
            this.inputDesc4Label.TabIndex = 9;
            this.inputDesc4Label.Text = "Hourly Pay Rate:";
            // 
            // createPWButton
            // 
            this.createPWButton.Location = new System.Drawing.Point(97, 159);
            this.createPWButton.Name = "createPWButton";
            this.createPWButton.Size = new System.Drawing.Size(75, 48);
            this.createPWButton.TabIndex = 10;
            this.createPWButton.Text = "Create Production Worker";
            this.createPWButton.UseVisualStyleBackColor = true;
            this.createPWButton.Click += new System.EventHandler(this.createPWButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(186, 159);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 48);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pwHPRLabel);
            this.panel2.Controls.Add(this.pwShiftNumLabel);
            this.panel2.Controls.Add(this.pwEmployeeNumberLabel);
            this.panel2.Controls.Add(this.pwNameLabel);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(12, 238);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(342, 159);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Hourly Pay Rate:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Production Woker Shift Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Production Woker Number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Production Woker Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Production Woker Data:";
            // 
            // pwHPRLabel
            // 
            this.pwHPRLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pwHPRLabel.Location = new System.Drawing.Point(183, 119);
            this.pwHPRLabel.Name = "pwHPRLabel";
            this.pwHPRLabel.Size = new System.Drawing.Size(136, 23);
            this.pwHPRLabel.TabIndex = 13;
            this.pwHPRLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pwShiftNumLabel
            // 
            this.pwShiftNumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pwShiftNumLabel.Location = new System.Drawing.Point(183, 93);
            this.pwShiftNumLabel.Name = "pwShiftNumLabel";
            this.pwShiftNumLabel.Size = new System.Drawing.Size(136, 23);
            this.pwShiftNumLabel.TabIndex = 12;
            this.pwShiftNumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pwEmployeeNumberLabel
            // 
            this.pwEmployeeNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pwEmployeeNumberLabel.Location = new System.Drawing.Point(183, 67);
            this.pwEmployeeNumberLabel.Name = "pwEmployeeNumberLabel";
            this.pwEmployeeNumberLabel.Size = new System.Drawing.Size(136, 23);
            this.pwEmployeeNumberLabel.TabIndex = 11;
            this.pwEmployeeNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pwNameLabel
            // 
            this.pwNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pwNameLabel.Location = new System.Drawing.Point(183, 41);
            this.pwNameLabel.Name = "pwNameLabel";
            this.pwNameLabel.Size = new System.Drawing.Size(136, 23);
            this.pwNameLabel.TabIndex = 10;
            this.pwNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 404);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Employee and ProductionWorker";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label descPanelLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createPWButton;
        private System.Windows.Forms.Label inputDesc4Label;
        private System.Windows.Forms.Label inputDesc3Label;
        private System.Windows.Forms.Label inputDesc2Label;
        private System.Windows.Forms.Label inputDesc1Label;
        private System.Windows.Forms.TextBox pwHPRTextBox;
        private System.Windows.Forms.TextBox pwShiftNumTextBox;
        private System.Windows.Forms.TextBox pwEmployeeNumberTextBox;
        private System.Windows.Forms.TextBox pwNameTextBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label pwHPRLabel;
        private System.Windows.Forms.Label pwShiftNumLabel;
        private System.Windows.Forms.Label pwEmployeeNumberLabel;
        private System.Windows.Forms.Label pwNameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

