﻿namespace M4PP3_Witter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.tLHPRLabel = new System.Windows.Forms.Label();
            this.tLShiftNumLabel = new System.Windows.Forms.Label();
            this.tLEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.tLNameLabel = new System.Windows.Forms.Label();
            this.tLHPRDescLabel = new System.Windows.Forms.Label();
            this.tLShiftNumberDescLabel = new System.Windows.Forms.Label();
            this.tLNumberDescLabel = new System.Windows.Forms.Label();
            this.tLNameDescLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.exitButton = new System.Windows.Forms.Button();
            this.createTLButton = new System.Windows.Forms.Button();
            this.inputDesc4Label = new System.Windows.Forms.Label();
            this.inputDesc3Label = new System.Windows.Forms.Label();
            this.inputDesc2Label = new System.Windows.Forms.Label();
            this.inputDesc1Label = new System.Windows.Forms.Label();
            this.pwHPRTextBox = new System.Windows.Forms.TextBox();
            this.pwShiftNumTextBox = new System.Windows.Forms.TextBox();
            this.pwEmployeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.pwNameTextBox = new System.Windows.Forms.TextBox();
            this.descPanelLabel = new System.Windows.Forms.Label();
            this.input6DescLabel = new System.Windows.Forms.Label();
            this.input5DescLabel = new System.Windows.Forms.Label();
            this.tLReqTrainHoursTextBox = new System.Windows.Forms.TextBox();
            this.tLMonthlyBonusTextBox = new System.Windows.Forms.TextBox();
            this.input7DescLabel = new System.Windows.Forms.Label();
            this.tLComTrainHoursTextBox = new System.Windows.Forms.TextBox();
            this.comTrainHoursLabel = new System.Windows.Forms.Label();
            this.reqTrainHoursLabel = new System.Windows.Forms.Label();
            this.monthlyBonusLabel = new System.Windows.Forms.Label();
            this.comTrainHoursDescLabel = new System.Windows.Forms.Label();
            this.reqTrainHoursDescLabel = new System.Windows.Forms.Label();
            this.monthlyBonusDescLabel = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.comTrainHoursDescLabel);
            this.panel2.Controls.Add(this.reqTrainHoursDescLabel);
            this.panel2.Controls.Add(this.monthlyBonusDescLabel);
            this.panel2.Controls.Add(this.comTrainHoursLabel);
            this.panel2.Controls.Add(this.reqTrainHoursLabel);
            this.panel2.Controls.Add(this.monthlyBonusLabel);
            this.panel2.Controls.Add(this.tLHPRLabel);
            this.panel2.Controls.Add(this.tLShiftNumLabel);
            this.panel2.Controls.Add(this.tLEmployeeNumberLabel);
            this.panel2.Controls.Add(this.tLNameLabel);
            this.panel2.Controls.Add(this.tLHPRDescLabel);
            this.panel2.Controls.Add(this.tLShiftNumberDescLabel);
            this.panel2.Controls.Add(this.tLNumberDescLabel);
            this.panel2.Controls.Add(this.tLNameDescLabel);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(12, 293);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(342, 236);
            this.panel2.TabIndex = 3;
            // 
            // tLHPRLabel
            // 
            this.tLHPRLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tLHPRLabel.Location = new System.Drawing.Point(183, 119);
            this.tLHPRLabel.Name = "tLHPRLabel";
            this.tLHPRLabel.Size = new System.Drawing.Size(136, 23);
            this.tLHPRLabel.TabIndex = 13;
            this.tLHPRLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tLShiftNumLabel
            // 
            this.tLShiftNumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tLShiftNumLabel.Location = new System.Drawing.Point(183, 93);
            this.tLShiftNumLabel.Name = "tLShiftNumLabel";
            this.tLShiftNumLabel.Size = new System.Drawing.Size(136, 23);
            this.tLShiftNumLabel.TabIndex = 12;
            this.tLShiftNumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tLEmployeeNumberLabel
            // 
            this.tLEmployeeNumberLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tLEmployeeNumberLabel.Location = new System.Drawing.Point(183, 67);
            this.tLEmployeeNumberLabel.Name = "tLEmployeeNumberLabel";
            this.tLEmployeeNumberLabel.Size = new System.Drawing.Size(136, 23);
            this.tLEmployeeNumberLabel.TabIndex = 11;
            this.tLEmployeeNumberLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tLNameLabel
            // 
            this.tLNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tLNameLabel.Location = new System.Drawing.Point(183, 41);
            this.tLNameLabel.Name = "tLNameLabel";
            this.tLNameLabel.Size = new System.Drawing.Size(136, 23);
            this.tLNameLabel.TabIndex = 10;
            this.tLNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tLHPRDescLabel
            // 
            this.tLHPRDescLabel.AutoSize = true;
            this.tLHPRDescLabel.Location = new System.Drawing.Point(12, 124);
            this.tLHPRDescLabel.Name = "tLHPRDescLabel";
            this.tLHPRDescLabel.Size = new System.Drawing.Size(87, 13);
            this.tLHPRDescLabel.TabIndex = 90;
            this.tLHPRDescLabel.Text = "Hourly Pay Rate:";
            // 
            // tLShiftNumberDescLabel
            // 
            this.tLShiftNumberDescLabel.AutoSize = true;
            this.tLShiftNumberDescLabel.Location = new System.Drawing.Point(12, 98);
            this.tLShiftNumberDescLabel.Name = "tLShiftNumberDescLabel";
            this.tLShiftNumberDescLabel.Size = new System.Drawing.Size(137, 13);
            this.tLShiftNumberDescLabel.TabIndex = 8;
            this.tLShiftNumberDescLabel.Text = "Team Leader Shift Number:";
            // 
            // tLNumberDescLabel
            // 
            this.tLNumberDescLabel.AutoSize = true;
            this.tLNumberDescLabel.Location = new System.Drawing.Point(12, 72);
            this.tLNumberDescLabel.Name = "tLNumberDescLabel";
            this.tLNumberDescLabel.Size = new System.Drawing.Size(113, 13);
            this.tLNumberDescLabel.TabIndex = 7;
            this.tLNumberDescLabel.Text = "Team Leader Number:";
            // 
            // tLNameDescLabel
            // 
            this.tLNameDescLabel.AutoSize = true;
            this.tLNameDescLabel.Location = new System.Drawing.Point(12, 46);
            this.tLNameDescLabel.Name = "tLNameDescLabel";
            this.tLNameDescLabel.Size = new System.Drawing.Size(104, 13);
            this.tLNameDescLabel.TabIndex = 6;
            this.tLNameDescLabel.Text = "Team Leader Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Team Leader Data:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.input7DescLabel);
            this.panel1.Controls.Add(this.tLComTrainHoursTextBox);
            this.panel1.Controls.Add(this.input6DescLabel);
            this.panel1.Controls.Add(this.input5DescLabel);
            this.panel1.Controls.Add(this.tLReqTrainHoursTextBox);
            this.panel1.Controls.Add(this.tLMonthlyBonusTextBox);
            this.panel1.Controls.Add(this.exitButton);
            this.panel1.Controls.Add(this.createTLButton);
            this.panel1.Controls.Add(this.inputDesc4Label);
            this.panel1.Controls.Add(this.inputDesc3Label);
            this.panel1.Controls.Add(this.inputDesc2Label);
            this.panel1.Controls.Add(this.inputDesc1Label);
            this.panel1.Controls.Add(this.pwHPRTextBox);
            this.panel1.Controls.Add(this.pwShiftNumTextBox);
            this.panel1.Controls.Add(this.pwEmployeeNumberTextBox);
            this.panel1.Controls.Add(this.pwNameTextBox);
            this.panel1.Controls.Add(this.descPanelLabel);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 275);
            this.panel1.TabIndex = 2;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(186, 231);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(131, 28);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // createTLButton
            // 
            this.createTLButton.Location = new System.Drawing.Point(41, 231);
            this.createTLButton.Name = "createTLButton";
            this.createTLButton.Size = new System.Drawing.Size(131, 28);
            this.createTLButton.TabIndex = 8;
            this.createTLButton.Text = "Create Team Leader";
            this.createTLButton.UseVisualStyleBackColor = true;
            this.createTLButton.Click += new System.EventHandler(this.createTLButton_Click);
            // 
            // inputDesc4Label
            // 
            this.inputDesc4Label.AutoSize = true;
            this.inputDesc4Label.Location = new System.Drawing.Point(12, 124);
            this.inputDesc4Label.Name = "inputDesc4Label";
            this.inputDesc4Label.Size = new System.Drawing.Size(87, 13);
            this.inputDesc4Label.TabIndex = 9;
            this.inputDesc4Label.Text = "Hourly Pay Rate:";
            // 
            // inputDesc3Label
            // 
            this.inputDesc3Label.AutoSize = true;
            this.inputDesc3Label.Location = new System.Drawing.Point(12, 98);
            this.inputDesc3Label.Name = "inputDesc3Label";
            this.inputDesc3Label.Size = new System.Drawing.Size(137, 13);
            this.inputDesc3Label.TabIndex = 8;
            this.inputDesc3Label.Text = "Team Leader Shift Number:";
            // 
            // inputDesc2Label
            // 
            this.inputDesc2Label.AutoSize = true;
            this.inputDesc2Label.Location = new System.Drawing.Point(12, 72);
            this.inputDesc2Label.Name = "inputDesc2Label";
            this.inputDesc2Label.Size = new System.Drawing.Size(113, 13);
            this.inputDesc2Label.TabIndex = 7;
            this.inputDesc2Label.Text = "Team Leader Number:";
            // 
            // inputDesc1Label
            // 
            this.inputDesc1Label.AutoSize = true;
            this.inputDesc1Label.Location = new System.Drawing.Point(12, 46);
            this.inputDesc1Label.Name = "inputDesc1Label";
            this.inputDesc1Label.Size = new System.Drawing.Size(104, 13);
            this.inputDesc1Label.TabIndex = 6;
            this.inputDesc1Label.Text = "Team Leader Name:";
            // 
            // pwHPRTextBox
            // 
            this.pwHPRTextBox.Location = new System.Drawing.Point(186, 121);
            this.pwHPRTextBox.Name = "pwHPRTextBox";
            this.pwHPRTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwHPRTextBox.TabIndex = 4;
            // 
            // pwShiftNumTextBox
            // 
            this.pwShiftNumTextBox.Location = new System.Drawing.Point(186, 95);
            this.pwShiftNumTextBox.Name = "pwShiftNumTextBox";
            this.pwShiftNumTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwShiftNumTextBox.TabIndex = 3;
            // 
            // pwEmployeeNumberTextBox
            // 
            this.pwEmployeeNumberTextBox.Location = new System.Drawing.Point(186, 69);
            this.pwEmployeeNumberTextBox.Name = "pwEmployeeNumberTextBox";
            this.pwEmployeeNumberTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwEmployeeNumberTextBox.TabIndex = 2;
            // 
            // pwNameTextBox
            // 
            this.pwNameTextBox.Location = new System.Drawing.Point(186, 43);
            this.pwNameTextBox.Name = "pwNameTextBox";
            this.pwNameTextBox.Size = new System.Drawing.Size(143, 20);
            this.pwNameTextBox.TabIndex = 1;
            // 
            // descPanelLabel
            // 
            this.descPanelLabel.AutoSize = true;
            this.descPanelLabel.Location = new System.Drawing.Point(12, 10);
            this.descPanelLabel.Name = "descPanelLabel";
            this.descPanelLabel.Size = new System.Drawing.Size(73, 13);
            this.descPanelLabel.TabIndex = 0;
            this.descPanelLabel.Text = "Team Leader:";
            // 
            // input6DescLabel
            // 
            this.input6DescLabel.AutoSize = true;
            this.input6DescLabel.Location = new System.Drawing.Point(12, 176);
            this.input6DescLabel.Name = "input6DescLabel";
            this.input6DescLabel.Size = new System.Drawing.Size(125, 13);
            this.input6DescLabel.TabIndex = 15;
            this.input6DescLabel.Text = "Required Training Hours:";
            // 
            // input5DescLabel
            // 
            this.input5DescLabel.AutoSize = true;
            this.input5DescLabel.Location = new System.Drawing.Point(12, 150);
            this.input5DescLabel.Name = "input5DescLabel";
            this.input5DescLabel.Size = new System.Drawing.Size(80, 13);
            this.input5DescLabel.TabIndex = 14;
            this.input5DescLabel.Text = "Monthly Bonus:";
            // 
            // tLReqTrainHoursTextBox
            // 
            this.tLReqTrainHoursTextBox.Location = new System.Drawing.Point(186, 173);
            this.tLReqTrainHoursTextBox.Name = "tLReqTrainHoursTextBox";
            this.tLReqTrainHoursTextBox.Size = new System.Drawing.Size(143, 20);
            this.tLReqTrainHoursTextBox.TabIndex = 6;
            // 
            // tLMonthlyBonusTextBox
            // 
            this.tLMonthlyBonusTextBox.Location = new System.Drawing.Point(186, 147);
            this.tLMonthlyBonusTextBox.Name = "tLMonthlyBonusTextBox";
            this.tLMonthlyBonusTextBox.Size = new System.Drawing.Size(143, 20);
            this.tLMonthlyBonusTextBox.TabIndex = 5;
            // 
            // input7DescLabel
            // 
            this.input7DescLabel.AutoSize = true;
            this.input7DescLabel.Location = new System.Drawing.Point(12, 202);
            this.input7DescLabel.Name = "input7DescLabel";
            this.input7DescLabel.Size = new System.Drawing.Size(132, 13);
            this.input7DescLabel.TabIndex = 17;
            this.input7DescLabel.Text = "Completed Training Hours:";
            // 
            // tLComTrainHoursTextBox
            // 
            this.tLComTrainHoursTextBox.Location = new System.Drawing.Point(186, 199);
            this.tLComTrainHoursTextBox.Name = "tLComTrainHoursTextBox";
            this.tLComTrainHoursTextBox.Size = new System.Drawing.Size(143, 20);
            this.tLComTrainHoursTextBox.TabIndex = 7;
            // 
            // comTrainHoursLabel
            // 
            this.comTrainHoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.comTrainHoursLabel.Location = new System.Drawing.Point(183, 198);
            this.comTrainHoursLabel.Name = "comTrainHoursLabel";
            this.comTrainHoursLabel.Size = new System.Drawing.Size(136, 23);
            this.comTrainHoursLabel.TabIndex = 16;
            this.comTrainHoursLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // reqTrainHoursLabel
            // 
            this.reqTrainHoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.reqTrainHoursLabel.Location = new System.Drawing.Point(183, 172);
            this.reqTrainHoursLabel.Name = "reqTrainHoursLabel";
            this.reqTrainHoursLabel.Size = new System.Drawing.Size(136, 23);
            this.reqTrainHoursLabel.TabIndex = 15;
            this.reqTrainHoursLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthlyBonusLabel
            // 
            this.monthlyBonusLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthlyBonusLabel.Location = new System.Drawing.Point(183, 146);
            this.monthlyBonusLabel.Name = "monthlyBonusLabel";
            this.monthlyBonusLabel.Size = new System.Drawing.Size(136, 23);
            this.monthlyBonusLabel.TabIndex = 14;
            this.monthlyBonusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comTrainHoursDescLabel
            // 
            this.comTrainHoursDescLabel.AutoSize = true;
            this.comTrainHoursDescLabel.Location = new System.Drawing.Point(12, 203);
            this.comTrainHoursDescLabel.Name = "comTrainHoursDescLabel";
            this.comTrainHoursDescLabel.Size = new System.Drawing.Size(132, 13);
            this.comTrainHoursDescLabel.TabIndex = 19;
            this.comTrainHoursDescLabel.Text = "Completed Training Hours:";
            // 
            // reqTrainHoursDescLabel
            // 
            this.reqTrainHoursDescLabel.AutoSize = true;
            this.reqTrainHoursDescLabel.Location = new System.Drawing.Point(12, 177);
            this.reqTrainHoursDescLabel.Name = "reqTrainHoursDescLabel";
            this.reqTrainHoursDescLabel.Size = new System.Drawing.Size(125, 13);
            this.reqTrainHoursDescLabel.TabIndex = 18;
            this.reqTrainHoursDescLabel.Text = "Required Training Hours:";
            // 
            // monthlyBonusDescLabel
            // 
            this.monthlyBonusDescLabel.AutoSize = true;
            this.monthlyBonusDescLabel.Location = new System.Drawing.Point(12, 151);
            this.monthlyBonusDescLabel.Name = "monthlyBonusDescLabel";
            this.monthlyBonusDescLabel.Size = new System.Drawing.Size(80, 13);
            this.monthlyBonusDescLabel.TabIndex = 17;
            this.monthlyBonusDescLabel.Text = "Monthly Bonus:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 534);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "TeamLeader Class";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label tLHPRLabel;
        private System.Windows.Forms.Label tLShiftNumLabel;
        private System.Windows.Forms.Label tLEmployeeNumberLabel;
        private System.Windows.Forms.Label tLNameLabel;
        private System.Windows.Forms.Label tLHPRDescLabel;
        private System.Windows.Forms.Label tLShiftNumberDescLabel;
        private System.Windows.Forms.Label tLNumberDescLabel;
        private System.Windows.Forms.Label tLNameDescLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createTLButton;
        private System.Windows.Forms.Label inputDesc4Label;
        private System.Windows.Forms.Label inputDesc3Label;
        private System.Windows.Forms.Label inputDesc2Label;
        private System.Windows.Forms.Label inputDesc1Label;
        private System.Windows.Forms.TextBox pwHPRTextBox;
        private System.Windows.Forms.TextBox pwShiftNumTextBox;
        private System.Windows.Forms.TextBox pwEmployeeNumberTextBox;
        private System.Windows.Forms.TextBox pwNameTextBox;
        private System.Windows.Forms.Label descPanelLabel;
        private System.Windows.Forms.Label comTrainHoursDescLabel;
        private System.Windows.Forms.Label reqTrainHoursDescLabel;
        private System.Windows.Forms.Label monthlyBonusDescLabel;
        private System.Windows.Forms.Label comTrainHoursLabel;
        private System.Windows.Forms.Label reqTrainHoursLabel;
        private System.Windows.Forms.Label monthlyBonusLabel;
        private System.Windows.Forms.Label input7DescLabel;
        private System.Windows.Forms.TextBox tLComTrainHoursTextBox;
        private System.Windows.Forms.Label input6DescLabel;
        private System.Windows.Forms.Label input5DescLabel;
        private System.Windows.Forms.TextBox tLReqTrainHoursTextBox;
        private System.Windows.Forms.TextBox tLMonthlyBonusTextBox;
    }
}

