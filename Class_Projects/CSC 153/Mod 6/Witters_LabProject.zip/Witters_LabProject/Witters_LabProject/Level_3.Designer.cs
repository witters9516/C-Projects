﻿namespace Witters_LabProject
{
    partial class Level_3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Level_3));
            this.card20BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card19BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card18BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card17BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card16BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card15BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card14BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card13BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card12BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card11BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card10BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card9BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card8BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card7BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card6BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card5BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card4BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card3BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card2BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card1BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card22BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card21BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card24BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card23BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card30BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card29BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card28BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card27BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card26BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card25BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card20FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card19FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card18FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card17FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card16FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card15FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card14FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card13FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card12FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card11FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card10FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card9FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card8FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card7FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card6FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card5FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card4FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card3FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card2FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card1FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card22FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card21FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card24FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card23FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card30FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card29FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card28FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card27FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card26FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card25FrontpictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.card20BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card30BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card29BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card28BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card27BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card26BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card25BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card30FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card29FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card28FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card27FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card26FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card25FrontpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // card20BackpictureBox
            // 
            this.card20BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card20BackpictureBox.Image")));
            this.card20BackpictureBox.Location = new System.Drawing.Point(114, 318);
            this.card20BackpictureBox.Name = "card20BackpictureBox";
            this.card20BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card20BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card20BackpictureBox.TabIndex = 75;
            this.card20BackpictureBox.TabStop = false;
            this.card20BackpictureBox.Click += new System.EventHandler(this.card20BackpictureBox_Click);
            // 
            // card19BackpictureBox
            // 
            this.card19BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card19BackpictureBox.Image")));
            this.card19BackpictureBox.Location = new System.Drawing.Point(12, 318);
            this.card19BackpictureBox.Name = "card19BackpictureBox";
            this.card19BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card19BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card19BackpictureBox.TabIndex = 74;
            this.card19BackpictureBox.TabStop = false;
            this.card19BackpictureBox.Click += new System.EventHandler(this.card19BackpictureBox_Click);
            // 
            // card18BackpictureBox
            // 
            this.card18BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card18BackpictureBox.Image")));
            this.card18BackpictureBox.Location = new System.Drawing.Point(524, 216);
            this.card18BackpictureBox.Name = "card18BackpictureBox";
            this.card18BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card18BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card18BackpictureBox.TabIndex = 73;
            this.card18BackpictureBox.TabStop = false;
            this.card18BackpictureBox.Click += new System.EventHandler(this.card18BackpictureBox_Click);
            // 
            // card17BackpictureBox
            // 
            this.card17BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card17BackpictureBox.Image")));
            this.card17BackpictureBox.Location = new System.Drawing.Point(422, 216);
            this.card17BackpictureBox.Name = "card17BackpictureBox";
            this.card17BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card17BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card17BackpictureBox.TabIndex = 72;
            this.card17BackpictureBox.TabStop = false;
            this.card17BackpictureBox.Click += new System.EventHandler(this.card17BackpictureBox_Click);
            // 
            // card16BackpictureBox
            // 
            this.card16BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card16BackpictureBox.Image")));
            this.card16BackpictureBox.Location = new System.Drawing.Point(318, 216);
            this.card16BackpictureBox.Name = "card16BackpictureBox";
            this.card16BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card16BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card16BackpictureBox.TabIndex = 71;
            this.card16BackpictureBox.TabStop = false;
            this.card16BackpictureBox.Click += new System.EventHandler(this.card16BackpictureBox_Click);
            // 
            // card15BackpictureBox
            // 
            this.card15BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card15BackpictureBox.Image")));
            this.card15BackpictureBox.Location = new System.Drawing.Point(216, 216);
            this.card15BackpictureBox.Name = "card15BackpictureBox";
            this.card15BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card15BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card15BackpictureBox.TabIndex = 70;
            this.card15BackpictureBox.TabStop = false;
            this.card15BackpictureBox.Click += new System.EventHandler(this.card15BackpictureBox_Click);
            // 
            // card14BackpictureBox
            // 
            this.card14BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card14BackpictureBox.Image")));
            this.card14BackpictureBox.Location = new System.Drawing.Point(114, 216);
            this.card14BackpictureBox.Name = "card14BackpictureBox";
            this.card14BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card14BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card14BackpictureBox.TabIndex = 69;
            this.card14BackpictureBox.TabStop = false;
            this.card14BackpictureBox.Click += new System.EventHandler(this.card14BackpictureBox_Click);
            // 
            // card13BackpictureBox
            // 
            this.card13BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card13BackpictureBox.Image")));
            this.card13BackpictureBox.Location = new System.Drawing.Point(12, 216);
            this.card13BackpictureBox.Name = "card13BackpictureBox";
            this.card13BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card13BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card13BackpictureBox.TabIndex = 68;
            this.card13BackpictureBox.TabStop = false;
            this.card13BackpictureBox.Click += new System.EventHandler(this.card13BackpictureBox_Click);
            // 
            // card12BackpictureBox
            // 
            this.card12BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12BackpictureBox.Image")));
            this.card12BackpictureBox.Location = new System.Drawing.Point(522, 114);
            this.card12BackpictureBox.Name = "card12BackpictureBox";
            this.card12BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card12BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12BackpictureBox.TabIndex = 67;
            this.card12BackpictureBox.TabStop = false;
            this.card12BackpictureBox.Click += new System.EventHandler(this.card12BackpictureBox_Click);
            // 
            // card11BackpictureBox
            // 
            this.card11BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11BackpictureBox.Image")));
            this.card11BackpictureBox.Location = new System.Drawing.Point(420, 114);
            this.card11BackpictureBox.Name = "card11BackpictureBox";
            this.card11BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card11BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11BackpictureBox.TabIndex = 66;
            this.card11BackpictureBox.TabStop = false;
            this.card11BackpictureBox.Click += new System.EventHandler(this.card11BackpictureBox_Click);
            // 
            // card10BackpictureBox
            // 
            this.card10BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10BackpictureBox.Image")));
            this.card10BackpictureBox.Location = new System.Drawing.Point(318, 114);
            this.card10BackpictureBox.Name = "card10BackpictureBox";
            this.card10BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card10BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10BackpictureBox.TabIndex = 65;
            this.card10BackpictureBox.TabStop = false;
            this.card10BackpictureBox.Click += new System.EventHandler(this.card10BackpictureBox_Click);
            // 
            // card9BackpictureBox
            // 
            this.card9BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9BackpictureBox.Image")));
            this.card9BackpictureBox.Location = new System.Drawing.Point(216, 114);
            this.card9BackpictureBox.Name = "card9BackpictureBox";
            this.card9BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card9BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9BackpictureBox.TabIndex = 64;
            this.card9BackpictureBox.TabStop = false;
            this.card9BackpictureBox.Click += new System.EventHandler(this.card9BackpictureBox_Click);
            // 
            // card8BackpictureBox
            // 
            this.card8BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8BackpictureBox.Image")));
            this.card8BackpictureBox.Location = new System.Drawing.Point(114, 114);
            this.card8BackpictureBox.Name = "card8BackpictureBox";
            this.card8BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card8BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8BackpictureBox.TabIndex = 63;
            this.card8BackpictureBox.TabStop = false;
            this.card8BackpictureBox.Click += new System.EventHandler(this.card8BackpictureBox_Click);
            // 
            // card7BackpictureBox
            // 
            this.card7BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7BackpictureBox.Image")));
            this.card7BackpictureBox.Location = new System.Drawing.Point(12, 114);
            this.card7BackpictureBox.Name = "card7BackpictureBox";
            this.card7BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card7BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7BackpictureBox.TabIndex = 62;
            this.card7BackpictureBox.TabStop = false;
            this.card7BackpictureBox.Click += new System.EventHandler(this.card7BackpictureBox_Click);
            // 
            // card6BackpictureBox
            // 
            this.card6BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6BackpictureBox.Image")));
            this.card6BackpictureBox.Location = new System.Drawing.Point(522, 12);
            this.card6BackpictureBox.Name = "card6BackpictureBox";
            this.card6BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card6BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6BackpictureBox.TabIndex = 61;
            this.card6BackpictureBox.TabStop = false;
            this.card6BackpictureBox.Click += new System.EventHandler(this.card6BackpictureBox_Click);
            // 
            // card5BackpictureBox
            // 
            this.card5BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5BackpictureBox.Image")));
            this.card5BackpictureBox.Location = new System.Drawing.Point(420, 12);
            this.card5BackpictureBox.Name = "card5BackpictureBox";
            this.card5BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card5BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5BackpictureBox.TabIndex = 60;
            this.card5BackpictureBox.TabStop = false;
            this.card5BackpictureBox.Click += new System.EventHandler(this.card5BackpictureBox_Click);
            // 
            // card4BackpictureBox
            // 
            this.card4BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4BackpictureBox.Image")));
            this.card4BackpictureBox.Location = new System.Drawing.Point(318, 12);
            this.card4BackpictureBox.Name = "card4BackpictureBox";
            this.card4BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card4BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4BackpictureBox.TabIndex = 59;
            this.card4BackpictureBox.TabStop = false;
            this.card4BackpictureBox.Click += new System.EventHandler(this.card4BackpictureBox_Click);
            // 
            // card3BackpictureBox
            // 
            this.card3BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3BackpictureBox.Image")));
            this.card3BackpictureBox.Location = new System.Drawing.Point(216, 12);
            this.card3BackpictureBox.Name = "card3BackpictureBox";
            this.card3BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card3BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3BackpictureBox.TabIndex = 58;
            this.card3BackpictureBox.TabStop = false;
            this.card3BackpictureBox.Click += new System.EventHandler(this.card3BackpictureBox_Click);
            // 
            // card2BackpictureBox
            // 
            this.card2BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2BackpictureBox.Image")));
            this.card2BackpictureBox.Location = new System.Drawing.Point(114, 12);
            this.card2BackpictureBox.Name = "card2BackpictureBox";
            this.card2BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card2BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2BackpictureBox.TabIndex = 57;
            this.card2BackpictureBox.TabStop = false;
            this.card2BackpictureBox.Click += new System.EventHandler(this.card2BackpictureBox_Click);
            // 
            // card1BackpictureBox
            // 
            this.card1BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1BackpictureBox.Image")));
            this.card1BackpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1BackpictureBox.Name = "card1BackpictureBox";
            this.card1BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card1BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1BackpictureBox.TabIndex = 56;
            this.card1BackpictureBox.TabStop = false;
            this.card1BackpictureBox.Click += new System.EventHandler(this.card1BackpictureBox_Click);
            // 
            // card22BackpictureBox
            // 
            this.card22BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card22BackpictureBox.Image")));
            this.card22BackpictureBox.Location = new System.Drawing.Point(318, 318);
            this.card22BackpictureBox.Name = "card22BackpictureBox";
            this.card22BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card22BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card22BackpictureBox.TabIndex = 77;
            this.card22BackpictureBox.TabStop = false;
            this.card22BackpictureBox.Click += new System.EventHandler(this.card22BackpictureBox_Click);
            // 
            // card21BackpictureBox
            // 
            this.card21BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card21BackpictureBox.Image")));
            this.card21BackpictureBox.Location = new System.Drawing.Point(216, 318);
            this.card21BackpictureBox.Name = "card21BackpictureBox";
            this.card21BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card21BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card21BackpictureBox.TabIndex = 76;
            this.card21BackpictureBox.TabStop = false;
            this.card21BackpictureBox.Click += new System.EventHandler(this.card21BackpictureBox_Click);
            // 
            // card24BackpictureBox
            // 
            this.card24BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card24BackpictureBox.Image")));
            this.card24BackpictureBox.Location = new System.Drawing.Point(524, 318);
            this.card24BackpictureBox.Name = "card24BackpictureBox";
            this.card24BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card24BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card24BackpictureBox.TabIndex = 79;
            this.card24BackpictureBox.TabStop = false;
            this.card24BackpictureBox.Click += new System.EventHandler(this.card24BackpictureBox_Click);
            // 
            // card23BackpictureBox
            // 
            this.card23BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card23BackpictureBox.Image")));
            this.card23BackpictureBox.Location = new System.Drawing.Point(420, 318);
            this.card23BackpictureBox.Name = "card23BackpictureBox";
            this.card23BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card23BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card23BackpictureBox.TabIndex = 78;
            this.card23BackpictureBox.TabStop = false;
            this.card23BackpictureBox.Click += new System.EventHandler(this.card23BackpictureBox_Click);
            // 
            // card30BackpictureBox
            // 
            this.card30BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card30BackpictureBox.Image")));
            this.card30BackpictureBox.Location = new System.Drawing.Point(524, 420);
            this.card30BackpictureBox.Name = "card30BackpictureBox";
            this.card30BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card30BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card30BackpictureBox.TabIndex = 85;
            this.card30BackpictureBox.TabStop = false;
            this.card30BackpictureBox.Click += new System.EventHandler(this.card30BackpictureBox_Click);
            // 
            // card29BackpictureBox
            // 
            this.card29BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card29BackpictureBox.Image")));
            this.card29BackpictureBox.Location = new System.Drawing.Point(420, 420);
            this.card29BackpictureBox.Name = "card29BackpictureBox";
            this.card29BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card29BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card29BackpictureBox.TabIndex = 84;
            this.card29BackpictureBox.TabStop = false;
            this.card29BackpictureBox.Click += new System.EventHandler(this.card29BackpictureBox_Click);
            // 
            // card28BackpictureBox
            // 
            this.card28BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card28BackpictureBox.Image")));
            this.card28BackpictureBox.Location = new System.Drawing.Point(318, 420);
            this.card28BackpictureBox.Name = "card28BackpictureBox";
            this.card28BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card28BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card28BackpictureBox.TabIndex = 83;
            this.card28BackpictureBox.TabStop = false;
            this.card28BackpictureBox.Click += new System.EventHandler(this.card28BackpictureBox_Click);
            // 
            // card27BackpictureBox
            // 
            this.card27BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card27BackpictureBox.Image")));
            this.card27BackpictureBox.Location = new System.Drawing.Point(216, 420);
            this.card27BackpictureBox.Name = "card27BackpictureBox";
            this.card27BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card27BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card27BackpictureBox.TabIndex = 82;
            this.card27BackpictureBox.TabStop = false;
            this.card27BackpictureBox.Click += new System.EventHandler(this.card27BackpictureBox_Click);
            // 
            // card26BackpictureBox
            // 
            this.card26BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card26BackpictureBox.Image")));
            this.card26BackpictureBox.Location = new System.Drawing.Point(114, 420);
            this.card26BackpictureBox.Name = "card26BackpictureBox";
            this.card26BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card26BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card26BackpictureBox.TabIndex = 81;
            this.card26BackpictureBox.TabStop = false;
            this.card26BackpictureBox.Click += new System.EventHandler(this.card26BackpictureBox_Click);
            // 
            // card25BackpictureBox
            // 
            this.card25BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card25BackpictureBox.Image")));
            this.card25BackpictureBox.Location = new System.Drawing.Point(12, 420);
            this.card25BackpictureBox.Name = "card25BackpictureBox";
            this.card25BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card25BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card25BackpictureBox.TabIndex = 80;
            this.card25BackpictureBox.TabStop = false;
            this.card25BackpictureBox.Click += new System.EventHandler(this.card25BackpictureBox_Click);
            // 
            // card20FrontpictureBox
            // 
            this.card20FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card20FrontpictureBox.Image")));
            this.card20FrontpictureBox.Location = new System.Drawing.Point(114, 318);
            this.card20FrontpictureBox.Name = "card20FrontpictureBox";
            this.card20FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card20FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card20FrontpictureBox.TabIndex = 105;
            this.card20FrontpictureBox.TabStop = false;
            // 
            // card19FrontpictureBox
            // 
            this.card19FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card19FrontpictureBox.Image")));
            this.card19FrontpictureBox.Location = new System.Drawing.Point(12, 318);
            this.card19FrontpictureBox.Name = "card19FrontpictureBox";
            this.card19FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card19FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card19FrontpictureBox.TabIndex = 104;
            this.card19FrontpictureBox.TabStop = false;
            // 
            // card18FrontpictureBox
            // 
            this.card18FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card18FrontpictureBox.Image")));
            this.card18FrontpictureBox.Location = new System.Drawing.Point(524, 216);
            this.card18FrontpictureBox.Name = "card18FrontpictureBox";
            this.card18FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card18FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card18FrontpictureBox.TabIndex = 103;
            this.card18FrontpictureBox.TabStop = false;
            // 
            // card17FrontpictureBox
            // 
            this.card17FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card17FrontpictureBox.Image")));
            this.card17FrontpictureBox.Location = new System.Drawing.Point(422, 216);
            this.card17FrontpictureBox.Name = "card17FrontpictureBox";
            this.card17FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card17FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card17FrontpictureBox.TabIndex = 102;
            this.card17FrontpictureBox.TabStop = false;
            // 
            // card16FrontpictureBox
            // 
            this.card16FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card16FrontpictureBox.Image")));
            this.card16FrontpictureBox.Location = new System.Drawing.Point(318, 216);
            this.card16FrontpictureBox.Name = "card16FrontpictureBox";
            this.card16FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card16FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card16FrontpictureBox.TabIndex = 101;
            this.card16FrontpictureBox.TabStop = false;
            // 
            // card15FrontpictureBox
            // 
            this.card15FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card15FrontpictureBox.Image")));
            this.card15FrontpictureBox.Location = new System.Drawing.Point(216, 216);
            this.card15FrontpictureBox.Name = "card15FrontpictureBox";
            this.card15FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card15FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card15FrontpictureBox.TabIndex = 100;
            this.card15FrontpictureBox.TabStop = false;
            // 
            // card14FrontpictureBox
            // 
            this.card14FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card14FrontpictureBox.Image")));
            this.card14FrontpictureBox.Location = new System.Drawing.Point(114, 216);
            this.card14FrontpictureBox.Name = "card14FrontpictureBox";
            this.card14FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card14FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card14FrontpictureBox.TabIndex = 99;
            this.card14FrontpictureBox.TabStop = false;
            // 
            // card13FrontpictureBox
            // 
            this.card13FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card13FrontpictureBox.Image")));
            this.card13FrontpictureBox.Location = new System.Drawing.Point(12, 216);
            this.card13FrontpictureBox.Name = "card13FrontpictureBox";
            this.card13FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card13FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card13FrontpictureBox.TabIndex = 98;
            this.card13FrontpictureBox.TabStop = false;
            // 
            // card12FrontpictureBox
            // 
            this.card12FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12FrontpictureBox.Image")));
            this.card12FrontpictureBox.Location = new System.Drawing.Point(522, 114);
            this.card12FrontpictureBox.Name = "card12FrontpictureBox";
            this.card12FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card12FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12FrontpictureBox.TabIndex = 97;
            this.card12FrontpictureBox.TabStop = false;
            // 
            // card11FrontpictureBox
            // 
            this.card11FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11FrontpictureBox.Image")));
            this.card11FrontpictureBox.Location = new System.Drawing.Point(420, 114);
            this.card11FrontpictureBox.Name = "card11FrontpictureBox";
            this.card11FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card11FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11FrontpictureBox.TabIndex = 96;
            this.card11FrontpictureBox.TabStop = false;
            // 
            // card10FrontpictureBox
            // 
            this.card10FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10FrontpictureBox.Image")));
            this.card10FrontpictureBox.Location = new System.Drawing.Point(318, 114);
            this.card10FrontpictureBox.Name = "card10FrontpictureBox";
            this.card10FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card10FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10FrontpictureBox.TabIndex = 95;
            this.card10FrontpictureBox.TabStop = false;
            // 
            // card9FrontpictureBox
            // 
            this.card9FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9FrontpictureBox.Image")));
            this.card9FrontpictureBox.Location = new System.Drawing.Point(216, 114);
            this.card9FrontpictureBox.Name = "card9FrontpictureBox";
            this.card9FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card9FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9FrontpictureBox.TabIndex = 94;
            this.card9FrontpictureBox.TabStop = false;
            // 
            // card8FrontpictureBox
            // 
            this.card8FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8FrontpictureBox.Image")));
            this.card8FrontpictureBox.Location = new System.Drawing.Point(114, 114);
            this.card8FrontpictureBox.Name = "card8FrontpictureBox";
            this.card8FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card8FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8FrontpictureBox.TabIndex = 93;
            this.card8FrontpictureBox.TabStop = false;
            // 
            // card7FrontpictureBox
            // 
            this.card7FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7FrontpictureBox.Image")));
            this.card7FrontpictureBox.Location = new System.Drawing.Point(12, 114);
            this.card7FrontpictureBox.Name = "card7FrontpictureBox";
            this.card7FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card7FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7FrontpictureBox.TabIndex = 92;
            this.card7FrontpictureBox.TabStop = false;
            // 
            // card6FrontpictureBox
            // 
            this.card6FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6FrontpictureBox.Image")));
            this.card6FrontpictureBox.Location = new System.Drawing.Point(522, 12);
            this.card6FrontpictureBox.Name = "card6FrontpictureBox";
            this.card6FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card6FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6FrontpictureBox.TabIndex = 91;
            this.card6FrontpictureBox.TabStop = false;
            // 
            // card5FrontpictureBox
            // 
            this.card5FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5FrontpictureBox.Image")));
            this.card5FrontpictureBox.Location = new System.Drawing.Point(420, 12);
            this.card5FrontpictureBox.Name = "card5FrontpictureBox";
            this.card5FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card5FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5FrontpictureBox.TabIndex = 90;
            this.card5FrontpictureBox.TabStop = false;
            // 
            // card4FrontpictureBox
            // 
            this.card4FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4FrontpictureBox.Image")));
            this.card4FrontpictureBox.Location = new System.Drawing.Point(318, 12);
            this.card4FrontpictureBox.Name = "card4FrontpictureBox";
            this.card4FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card4FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4FrontpictureBox.TabIndex = 89;
            this.card4FrontpictureBox.TabStop = false;
            // 
            // card3FrontpictureBox
            // 
            this.card3FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3FrontpictureBox.Image")));
            this.card3FrontpictureBox.Location = new System.Drawing.Point(216, 12);
            this.card3FrontpictureBox.Name = "card3FrontpictureBox";
            this.card3FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card3FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3FrontpictureBox.TabIndex = 88;
            this.card3FrontpictureBox.TabStop = false;
            // 
            // card2FrontpictureBox
            // 
            this.card2FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2FrontpictureBox.Image")));
            this.card2FrontpictureBox.Location = new System.Drawing.Point(114, 12);
            this.card2FrontpictureBox.Name = "card2FrontpictureBox";
            this.card2FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card2FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2FrontpictureBox.TabIndex = 87;
            this.card2FrontpictureBox.TabStop = false;
            // 
            // card1FrontpictureBox
            // 
            this.card1FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1FrontpictureBox.Image")));
            this.card1FrontpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1FrontpictureBox.Name = "card1FrontpictureBox";
            this.card1FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card1FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1FrontpictureBox.TabIndex = 86;
            this.card1FrontpictureBox.TabStop = false;
            // 
            // card22FrontpictureBox
            // 
            this.card22FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card22FrontpictureBox.Image")));
            this.card22FrontpictureBox.Location = new System.Drawing.Point(318, 318);
            this.card22FrontpictureBox.Name = "card22FrontpictureBox";
            this.card22FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card22FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card22FrontpictureBox.TabIndex = 107;
            this.card22FrontpictureBox.TabStop = false;
            // 
            // card21FrontpictureBox
            // 
            this.card21FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card21FrontpictureBox.Image")));
            this.card21FrontpictureBox.Location = new System.Drawing.Point(216, 318);
            this.card21FrontpictureBox.Name = "card21FrontpictureBox";
            this.card21FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card21FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card21FrontpictureBox.TabIndex = 106;
            this.card21FrontpictureBox.TabStop = false;
            // 
            // card24FrontpictureBox
            // 
            this.card24FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card24FrontpictureBox.Image")));
            this.card24FrontpictureBox.Location = new System.Drawing.Point(524, 318);
            this.card24FrontpictureBox.Name = "card24FrontpictureBox";
            this.card24FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card24FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card24FrontpictureBox.TabIndex = 109;
            this.card24FrontpictureBox.TabStop = false;
            // 
            // card23FrontpictureBox
            // 
            this.card23FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card23FrontpictureBox.Image")));
            this.card23FrontpictureBox.Location = new System.Drawing.Point(420, 318);
            this.card23FrontpictureBox.Name = "card23FrontpictureBox";
            this.card23FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card23FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card23FrontpictureBox.TabIndex = 108;
            this.card23FrontpictureBox.TabStop = false;
            // 
            // card30FrontpictureBox
            // 
            this.card30FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card30FrontpictureBox.Image")));
            this.card30FrontpictureBox.Location = new System.Drawing.Point(524, 420);
            this.card30FrontpictureBox.Name = "card30FrontpictureBox";
            this.card30FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card30FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card30FrontpictureBox.TabIndex = 115;
            this.card30FrontpictureBox.TabStop = false;
            // 
            // card29FrontpictureBox
            // 
            this.card29FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card29FrontpictureBox.Image")));
            this.card29FrontpictureBox.Location = new System.Drawing.Point(420, 420);
            this.card29FrontpictureBox.Name = "card29FrontpictureBox";
            this.card29FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card29FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card29FrontpictureBox.TabIndex = 114;
            this.card29FrontpictureBox.TabStop = false;
            // 
            // card28FrontpictureBox
            // 
            this.card28FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card28FrontpictureBox.Image")));
            this.card28FrontpictureBox.Location = new System.Drawing.Point(318, 420);
            this.card28FrontpictureBox.Name = "card28FrontpictureBox";
            this.card28FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card28FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card28FrontpictureBox.TabIndex = 113;
            this.card28FrontpictureBox.TabStop = false;
            // 
            // card27FrontpictureBox
            // 
            this.card27FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card27FrontpictureBox.Image")));
            this.card27FrontpictureBox.Location = new System.Drawing.Point(216, 420);
            this.card27FrontpictureBox.Name = "card27FrontpictureBox";
            this.card27FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card27FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card27FrontpictureBox.TabIndex = 112;
            this.card27FrontpictureBox.TabStop = false;
            // 
            // card26FrontpictureBox
            // 
            this.card26FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card26FrontpictureBox.Image")));
            this.card26FrontpictureBox.Location = new System.Drawing.Point(114, 420);
            this.card26FrontpictureBox.Name = "card26FrontpictureBox";
            this.card26FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card26FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card26FrontpictureBox.TabIndex = 111;
            this.card26FrontpictureBox.TabStop = false;
            // 
            // card25FrontpictureBox
            // 
            this.card25FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card25FrontpictureBox.Image")));
            this.card25FrontpictureBox.Location = new System.Drawing.Point(12, 420);
            this.card25FrontpictureBox.Name = "card25FrontpictureBox";
            this.card25FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card25FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card25FrontpictureBox.TabIndex = 110;
            this.card25FrontpictureBox.TabStop = false;
            // 
            // Level_3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(628, 525);
            this.Controls.Add(this.card30BackpictureBox);
            this.Controls.Add(this.card29BackpictureBox);
            this.Controls.Add(this.card28BackpictureBox);
            this.Controls.Add(this.card27BackpictureBox);
            this.Controls.Add(this.card26BackpictureBox);
            this.Controls.Add(this.card25BackpictureBox);
            this.Controls.Add(this.card24BackpictureBox);
            this.Controls.Add(this.card23BackpictureBox);
            this.Controls.Add(this.card22BackpictureBox);
            this.Controls.Add(this.card21BackpictureBox);
            this.Controls.Add(this.card20BackpictureBox);
            this.Controls.Add(this.card19BackpictureBox);
            this.Controls.Add(this.card18BackpictureBox);
            this.Controls.Add(this.card17BackpictureBox);
            this.Controls.Add(this.card16BackpictureBox);
            this.Controls.Add(this.card15BackpictureBox);
            this.Controls.Add(this.card14BackpictureBox);
            this.Controls.Add(this.card13BackpictureBox);
            this.Controls.Add(this.card12BackpictureBox);
            this.Controls.Add(this.card11BackpictureBox);
            this.Controls.Add(this.card10BackpictureBox);
            this.Controls.Add(this.card9BackpictureBox);
            this.Controls.Add(this.card8BackpictureBox);
            this.Controls.Add(this.card7BackpictureBox);
            this.Controls.Add(this.card6BackpictureBox);
            this.Controls.Add(this.card5BackpictureBox);
            this.Controls.Add(this.card4BackpictureBox);
            this.Controls.Add(this.card3BackpictureBox);
            this.Controls.Add(this.card2BackpictureBox);
            this.Controls.Add(this.card1BackpictureBox);
            this.Controls.Add(this.card30FrontpictureBox);
            this.Controls.Add(this.card29FrontpictureBox);
            this.Controls.Add(this.card28FrontpictureBox);
            this.Controls.Add(this.card27FrontpictureBox);
            this.Controls.Add(this.card26FrontpictureBox);
            this.Controls.Add(this.card25FrontpictureBox);
            this.Controls.Add(this.card24FrontpictureBox);
            this.Controls.Add(this.card23FrontpictureBox);
            this.Controls.Add(this.card22FrontpictureBox);
            this.Controls.Add(this.card21FrontpictureBox);
            this.Controls.Add(this.card20FrontpictureBox);
            this.Controls.Add(this.card19FrontpictureBox);
            this.Controls.Add(this.card18FrontpictureBox);
            this.Controls.Add(this.card17FrontpictureBox);
            this.Controls.Add(this.card16FrontpictureBox);
            this.Controls.Add(this.card15FrontpictureBox);
            this.Controls.Add(this.card14FrontpictureBox);
            this.Controls.Add(this.card13FrontpictureBox);
            this.Controls.Add(this.card12FrontpictureBox);
            this.Controls.Add(this.card11FrontpictureBox);
            this.Controls.Add(this.card10FrontpictureBox);
            this.Controls.Add(this.card9FrontpictureBox);
            this.Controls.Add(this.card8FrontpictureBox);
            this.Controls.Add(this.card7FrontpictureBox);
            this.Controls.Add(this.card6FrontpictureBox);
            this.Controls.Add(this.card5FrontpictureBox);
            this.Controls.Add(this.card4FrontpictureBox);
            this.Controls.Add(this.card3FrontpictureBox);
            this.Controls.Add(this.card2FrontpictureBox);
            this.Controls.Add(this.card1FrontpictureBox);
            this.Name = "Level_3";
            this.Text = "Level_3";
            ((System.ComponentModel.ISupportInitialize)(this.card20BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card30BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card29BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card28BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card27BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card26BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card25BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card22FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card21FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card24FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card23FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card30FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card29FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card28FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card27FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card26FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card25FrontpictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox card20BackpictureBox;
        private System.Windows.Forms.PictureBox card19BackpictureBox;
        private System.Windows.Forms.PictureBox card18BackpictureBox;
        private System.Windows.Forms.PictureBox card17BackpictureBox;
        private System.Windows.Forms.PictureBox card16BackpictureBox;
        private System.Windows.Forms.PictureBox card15BackpictureBox;
        private System.Windows.Forms.PictureBox card14BackpictureBox;
        private System.Windows.Forms.PictureBox card13BackpictureBox;
        private System.Windows.Forms.PictureBox card12BackpictureBox;
        private System.Windows.Forms.PictureBox card11BackpictureBox;
        private System.Windows.Forms.PictureBox card10BackpictureBox;
        private System.Windows.Forms.PictureBox card9BackpictureBox;
        private System.Windows.Forms.PictureBox card8BackpictureBox;
        private System.Windows.Forms.PictureBox card7BackpictureBox;
        private System.Windows.Forms.PictureBox card6BackpictureBox;
        private System.Windows.Forms.PictureBox card5BackpictureBox;
        private System.Windows.Forms.PictureBox card4BackpictureBox;
        private System.Windows.Forms.PictureBox card3BackpictureBox;
        private System.Windows.Forms.PictureBox card2BackpictureBox;
        private System.Windows.Forms.PictureBox card1BackpictureBox;
        private System.Windows.Forms.PictureBox card22BackpictureBox;
        private System.Windows.Forms.PictureBox card21BackpictureBox;
        private System.Windows.Forms.PictureBox card24BackpictureBox;
        private System.Windows.Forms.PictureBox card23BackpictureBox;
        private System.Windows.Forms.PictureBox card30BackpictureBox;
        private System.Windows.Forms.PictureBox card29BackpictureBox;
        private System.Windows.Forms.PictureBox card28BackpictureBox;
        private System.Windows.Forms.PictureBox card27BackpictureBox;
        private System.Windows.Forms.PictureBox card26BackpictureBox;
        private System.Windows.Forms.PictureBox card25BackpictureBox;
        private System.Windows.Forms.PictureBox card20FrontpictureBox;
        private System.Windows.Forms.PictureBox card19FrontpictureBox;
        private System.Windows.Forms.PictureBox card18FrontpictureBox;
        private System.Windows.Forms.PictureBox card17FrontpictureBox;
        private System.Windows.Forms.PictureBox card16FrontpictureBox;
        private System.Windows.Forms.PictureBox card15FrontpictureBox;
        private System.Windows.Forms.PictureBox card14FrontpictureBox;
        private System.Windows.Forms.PictureBox card13FrontpictureBox;
        private System.Windows.Forms.PictureBox card12FrontpictureBox;
        private System.Windows.Forms.PictureBox card11FrontpictureBox;
        private System.Windows.Forms.PictureBox card10FrontpictureBox;
        private System.Windows.Forms.PictureBox card9FrontpictureBox;
        private System.Windows.Forms.PictureBox card8FrontpictureBox;
        private System.Windows.Forms.PictureBox card7FrontpictureBox;
        private System.Windows.Forms.PictureBox card6FrontpictureBox;
        private System.Windows.Forms.PictureBox card5FrontpictureBox;
        private System.Windows.Forms.PictureBox card4FrontpictureBox;
        private System.Windows.Forms.PictureBox card3FrontpictureBox;
        private System.Windows.Forms.PictureBox card2FrontpictureBox;
        private System.Windows.Forms.PictureBox card1FrontpictureBox;
        private System.Windows.Forms.PictureBox card22FrontpictureBox;
        private System.Windows.Forms.PictureBox card21FrontpictureBox;
        private System.Windows.Forms.PictureBox card24FrontpictureBox;
        private System.Windows.Forms.PictureBox card23FrontpictureBox;
        private System.Windows.Forms.PictureBox card30FrontpictureBox;
        private System.Windows.Forms.PictureBox card29FrontpictureBox;
        private System.Windows.Forms.PictureBox card28FrontpictureBox;
        private System.Windows.Forms.PictureBox card27FrontpictureBox;
        private System.Windows.Forms.PictureBox card26FrontpictureBox;
        private System.Windows.Forms.PictureBox card25FrontpictureBox;
    }
}