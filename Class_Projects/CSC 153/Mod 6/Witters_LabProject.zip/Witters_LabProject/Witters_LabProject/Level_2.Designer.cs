﻿namespace Witters_LabProject
{
    partial class Level_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Level_2));
            this.card12BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card11BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card10BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card9BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card8BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card7BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card6BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card5BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card4BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card3BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card2BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card1BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card14BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card13BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card15BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card20BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card19BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card18BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card17BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card16BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card20FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card19FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card18FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card17FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card16FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card15FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card14FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card13FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card12FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card11FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card10FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card9FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card8FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card7FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card6FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card5FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card4FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card3FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card2FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card1FrontpictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // card12BackpictureBox
            // 
            this.card12BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12BackpictureBox.Image")));
            this.card12BackpictureBox.Location = new System.Drawing.Point(114, 216);
            this.card12BackpictureBox.Name = "card12BackpictureBox";
            this.card12BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card12BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12BackpictureBox.TabIndex = 47;
            this.card12BackpictureBox.TabStop = false;
            this.card12BackpictureBox.Click += new System.EventHandler(this.card12BackpictureBox_Click);
            // 
            // card11BackpictureBox
            // 
            this.card11BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11BackpictureBox.Image")));
            this.card11BackpictureBox.Location = new System.Drawing.Point(12, 216);
            this.card11BackpictureBox.Name = "card11BackpictureBox";
            this.card11BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card11BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11BackpictureBox.TabIndex = 46;
            this.card11BackpictureBox.TabStop = false;
            this.card11BackpictureBox.Click += new System.EventHandler(this.card11BackpictureBox_Click);
            // 
            // card10BackpictureBox
            // 
            this.card10BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10BackpictureBox.Image")));
            this.card10BackpictureBox.Location = new System.Drawing.Point(420, 114);
            this.card10BackpictureBox.Name = "card10BackpictureBox";
            this.card10BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card10BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10BackpictureBox.TabIndex = 45;
            this.card10BackpictureBox.TabStop = false;
            this.card10BackpictureBox.Click += new System.EventHandler(this.card10BackpictureBox_Click);
            // 
            // card9BackpictureBox
            // 
            this.card9BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9BackpictureBox.Image")));
            this.card9BackpictureBox.Location = new System.Drawing.Point(318, 114);
            this.card9BackpictureBox.Name = "card9BackpictureBox";
            this.card9BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card9BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9BackpictureBox.TabIndex = 44;
            this.card9BackpictureBox.TabStop = false;
            this.card9BackpictureBox.Click += new System.EventHandler(this.card9BackpictureBox_Click);
            // 
            // card8BackpictureBox
            // 
            this.card8BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8BackpictureBox.Image")));
            this.card8BackpictureBox.Location = new System.Drawing.Point(216, 114);
            this.card8BackpictureBox.Name = "card8BackpictureBox";
            this.card8BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card8BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8BackpictureBox.TabIndex = 43;
            this.card8BackpictureBox.TabStop = false;
            this.card8BackpictureBox.Click += new System.EventHandler(this.card8BackpictureBox_Click);
            // 
            // card7BackpictureBox
            // 
            this.card7BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7BackpictureBox.Image")));
            this.card7BackpictureBox.Location = new System.Drawing.Point(114, 114);
            this.card7BackpictureBox.Name = "card7BackpictureBox";
            this.card7BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card7BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7BackpictureBox.TabIndex = 42;
            this.card7BackpictureBox.TabStop = false;
            this.card7BackpictureBox.Click += new System.EventHandler(this.card7BackpictureBox_Click);
            // 
            // card6BackpictureBox
            // 
            this.card6BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6BackpictureBox.Image")));
            this.card6BackpictureBox.Location = new System.Drawing.Point(12, 114);
            this.card6BackpictureBox.Name = "card6BackpictureBox";
            this.card6BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card6BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6BackpictureBox.TabIndex = 41;
            this.card6BackpictureBox.TabStop = false;
            this.card6BackpictureBox.Click += new System.EventHandler(this.card6BackpictureBox_Click);
            // 
            // card5BackpictureBox
            // 
            this.card5BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5BackpictureBox.Image")));
            this.card5BackpictureBox.Location = new System.Drawing.Point(420, 12);
            this.card5BackpictureBox.Name = "card5BackpictureBox";
            this.card5BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card5BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5BackpictureBox.TabIndex = 40;
            this.card5BackpictureBox.TabStop = false;
            this.card5BackpictureBox.Click += new System.EventHandler(this.card5BackpictureBox_Click);
            // 
            // card4BackpictureBox
            // 
            this.card4BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4BackpictureBox.Image")));
            this.card4BackpictureBox.Location = new System.Drawing.Point(318, 12);
            this.card4BackpictureBox.Name = "card4BackpictureBox";
            this.card4BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card4BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4BackpictureBox.TabIndex = 39;
            this.card4BackpictureBox.TabStop = false;
            this.card4BackpictureBox.Click += new System.EventHandler(this.card4BackpictureBox_Click);
            // 
            // card3BackpictureBox
            // 
            this.card3BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3BackpictureBox.Image")));
            this.card3BackpictureBox.Location = new System.Drawing.Point(216, 12);
            this.card3BackpictureBox.Name = "card3BackpictureBox";
            this.card3BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card3BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3BackpictureBox.TabIndex = 38;
            this.card3BackpictureBox.TabStop = false;
            this.card3BackpictureBox.Click += new System.EventHandler(this.card3BackpictureBox_Click);
            // 
            // card2BackpictureBox
            // 
            this.card2BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2BackpictureBox.Image")));
            this.card2BackpictureBox.Location = new System.Drawing.Point(114, 12);
            this.card2BackpictureBox.Name = "card2BackpictureBox";
            this.card2BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card2BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2BackpictureBox.TabIndex = 37;
            this.card2BackpictureBox.TabStop = false;
            this.card2BackpictureBox.Click += new System.EventHandler(this.card2BackpictureBox_Click);
            // 
            // card1BackpictureBox
            // 
            this.card1BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1BackpictureBox.Image")));
            this.card1BackpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1BackpictureBox.Name = "card1BackpictureBox";
            this.card1BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card1BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1BackpictureBox.TabIndex = 36;
            this.card1BackpictureBox.TabStop = false;
            this.card1BackpictureBox.Click += new System.EventHandler(this.card1BackpictureBox_Click);
            // 
            // card14BackpictureBox
            // 
            this.card14BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card14BackpictureBox.Image")));
            this.card14BackpictureBox.Location = new System.Drawing.Point(318, 216);
            this.card14BackpictureBox.Name = "card14BackpictureBox";
            this.card14BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card14BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card14BackpictureBox.TabIndex = 49;
            this.card14BackpictureBox.TabStop = false;
            this.card14BackpictureBox.Click += new System.EventHandler(this.card14BackpictureBox_Click);
            // 
            // card13BackpictureBox
            // 
            this.card13BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card13BackpictureBox.Image")));
            this.card13BackpictureBox.Location = new System.Drawing.Point(216, 216);
            this.card13BackpictureBox.Name = "card13BackpictureBox";
            this.card13BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card13BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card13BackpictureBox.TabIndex = 48;
            this.card13BackpictureBox.TabStop = false;
            this.card13BackpictureBox.Click += new System.EventHandler(this.card13BackpictureBox_Click);
            // 
            // card15BackpictureBox
            // 
            this.card15BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card15BackpictureBox.Image")));
            this.card15BackpictureBox.Location = new System.Drawing.Point(420, 216);
            this.card15BackpictureBox.Name = "card15BackpictureBox";
            this.card15BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card15BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card15BackpictureBox.TabIndex = 50;
            this.card15BackpictureBox.TabStop = false;
            this.card15BackpictureBox.Click += new System.EventHandler(this.card15BackpictureBox_Click);
            // 
            // card20BackpictureBox
            // 
            this.card20BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card20BackpictureBox.Image")));
            this.card20BackpictureBox.Location = new System.Drawing.Point(420, 318);
            this.card20BackpictureBox.Name = "card20BackpictureBox";
            this.card20BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card20BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card20BackpictureBox.TabIndex = 55;
            this.card20BackpictureBox.TabStop = false;
            this.card20BackpictureBox.Click += new System.EventHandler(this.card20BackpictureBox_Click);
            // 
            // card19BackpictureBox
            // 
            this.card19BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card19BackpictureBox.Image")));
            this.card19BackpictureBox.Location = new System.Drawing.Point(318, 318);
            this.card19BackpictureBox.Name = "card19BackpictureBox";
            this.card19BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card19BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card19BackpictureBox.TabIndex = 54;
            this.card19BackpictureBox.TabStop = false;
            this.card19BackpictureBox.Click += new System.EventHandler(this.card19BackpictureBox_Click);
            // 
            // card18BackpictureBox
            // 
            this.card18BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card18BackpictureBox.Image")));
            this.card18BackpictureBox.Location = new System.Drawing.Point(216, 318);
            this.card18BackpictureBox.Name = "card18BackpictureBox";
            this.card18BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card18BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card18BackpictureBox.TabIndex = 53;
            this.card18BackpictureBox.TabStop = false;
            this.card18BackpictureBox.Click += new System.EventHandler(this.card18BackpictureBox_Click);
            // 
            // card17BackpictureBox
            // 
            this.card17BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card17BackpictureBox.Image")));
            this.card17BackpictureBox.Location = new System.Drawing.Point(114, 318);
            this.card17BackpictureBox.Name = "card17BackpictureBox";
            this.card17BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card17BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card17BackpictureBox.TabIndex = 52;
            this.card17BackpictureBox.TabStop = false;
            this.card17BackpictureBox.Click += new System.EventHandler(this.card17BackpictureBox_Click);
            // 
            // card16BackpictureBox
            // 
            this.card16BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card16BackpictureBox.Image")));
            this.card16BackpictureBox.Location = new System.Drawing.Point(12, 318);
            this.card16BackpictureBox.Name = "card16BackpictureBox";
            this.card16BackpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card16BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card16BackpictureBox.TabIndex = 51;
            this.card16BackpictureBox.TabStop = false;
            this.card16BackpictureBox.Click += new System.EventHandler(this.card16BackpictureBox_Click);
            // 
            // card20FrontpictureBox
            // 
            this.card20FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card20FrontpictureBox.Image")));
            this.card20FrontpictureBox.Location = new System.Drawing.Point(420, 318);
            this.card20FrontpictureBox.Name = "card20FrontpictureBox";
            this.card20FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card20FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card20FrontpictureBox.TabIndex = 75;
            this.card20FrontpictureBox.TabStop = false;
            // 
            // card19FrontpictureBox
            // 
            this.card19FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card19FrontpictureBox.Image")));
            this.card19FrontpictureBox.Location = new System.Drawing.Point(318, 318);
            this.card19FrontpictureBox.Name = "card19FrontpictureBox";
            this.card19FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card19FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card19FrontpictureBox.TabIndex = 74;
            this.card19FrontpictureBox.TabStop = false;
            // 
            // card18FrontpictureBox
            // 
            this.card18FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card18FrontpictureBox.Image")));
            this.card18FrontpictureBox.Location = new System.Drawing.Point(216, 318);
            this.card18FrontpictureBox.Name = "card18FrontpictureBox";
            this.card18FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card18FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card18FrontpictureBox.TabIndex = 73;
            this.card18FrontpictureBox.TabStop = false;
            // 
            // card17FrontpictureBox
            // 
            this.card17FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card17FrontpictureBox.Image")));
            this.card17FrontpictureBox.Location = new System.Drawing.Point(114, 318);
            this.card17FrontpictureBox.Name = "card17FrontpictureBox";
            this.card17FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card17FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card17FrontpictureBox.TabIndex = 72;
            this.card17FrontpictureBox.TabStop = false;
            // 
            // card16FrontpictureBox
            // 
            this.card16FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card16FrontpictureBox.Image")));
            this.card16FrontpictureBox.Location = new System.Drawing.Point(12, 318);
            this.card16FrontpictureBox.Name = "card16FrontpictureBox";
            this.card16FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card16FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card16FrontpictureBox.TabIndex = 71;
            this.card16FrontpictureBox.TabStop = false;
            // 
            // card15FrontpictureBox
            // 
            this.card15FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card15FrontpictureBox.Image")));
            this.card15FrontpictureBox.Location = new System.Drawing.Point(420, 216);
            this.card15FrontpictureBox.Name = "card15FrontpictureBox";
            this.card15FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card15FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card15FrontpictureBox.TabIndex = 70;
            this.card15FrontpictureBox.TabStop = false;
            // 
            // card14FrontpictureBox
            // 
            this.card14FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card14FrontpictureBox.Image")));
            this.card14FrontpictureBox.Location = new System.Drawing.Point(318, 216);
            this.card14FrontpictureBox.Name = "card14FrontpictureBox";
            this.card14FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card14FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card14FrontpictureBox.TabIndex = 69;
            this.card14FrontpictureBox.TabStop = false;
            // 
            // card13FrontpictureBox
            // 
            this.card13FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card13FrontpictureBox.Image")));
            this.card13FrontpictureBox.Location = new System.Drawing.Point(216, 216);
            this.card13FrontpictureBox.Name = "card13FrontpictureBox";
            this.card13FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card13FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card13FrontpictureBox.TabIndex = 68;
            this.card13FrontpictureBox.TabStop = false;
            // 
            // card12FrontpictureBox
            // 
            this.card12FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12FrontpictureBox.Image")));
            this.card12FrontpictureBox.Location = new System.Drawing.Point(114, 216);
            this.card12FrontpictureBox.Name = "card12FrontpictureBox";
            this.card12FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card12FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12FrontpictureBox.TabIndex = 67;
            this.card12FrontpictureBox.TabStop = false;
            // 
            // card11FrontpictureBox
            // 
            this.card11FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11FrontpictureBox.Image")));
            this.card11FrontpictureBox.Location = new System.Drawing.Point(12, 216);
            this.card11FrontpictureBox.Name = "card11FrontpictureBox";
            this.card11FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card11FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11FrontpictureBox.TabIndex = 66;
            this.card11FrontpictureBox.TabStop = false;
            // 
            // card10FrontpictureBox
            // 
            this.card10FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10FrontpictureBox.Image")));
            this.card10FrontpictureBox.Location = new System.Drawing.Point(420, 114);
            this.card10FrontpictureBox.Name = "card10FrontpictureBox";
            this.card10FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card10FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10FrontpictureBox.TabIndex = 65;
            this.card10FrontpictureBox.TabStop = false;
            // 
            // card9FrontpictureBox
            // 
            this.card9FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9FrontpictureBox.Image")));
            this.card9FrontpictureBox.Location = new System.Drawing.Point(318, 114);
            this.card9FrontpictureBox.Name = "card9FrontpictureBox";
            this.card9FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card9FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9FrontpictureBox.TabIndex = 64;
            this.card9FrontpictureBox.TabStop = false;
            // 
            // card8FrontpictureBox
            // 
            this.card8FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8FrontpictureBox.Image")));
            this.card8FrontpictureBox.Location = new System.Drawing.Point(216, 114);
            this.card8FrontpictureBox.Name = "card8FrontpictureBox";
            this.card8FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card8FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8FrontpictureBox.TabIndex = 63;
            this.card8FrontpictureBox.TabStop = false;
            // 
            // card7FrontpictureBox
            // 
            this.card7FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7FrontpictureBox.Image")));
            this.card7FrontpictureBox.Location = new System.Drawing.Point(114, 114);
            this.card7FrontpictureBox.Name = "card7FrontpictureBox";
            this.card7FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card7FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7FrontpictureBox.TabIndex = 62;
            this.card7FrontpictureBox.TabStop = false;
            // 
            // card6FrontpictureBox
            // 
            this.card6FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6FrontpictureBox.Image")));
            this.card6FrontpictureBox.Location = new System.Drawing.Point(12, 114);
            this.card6FrontpictureBox.Name = "card6FrontpictureBox";
            this.card6FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card6FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6FrontpictureBox.TabIndex = 61;
            this.card6FrontpictureBox.TabStop = false;
            // 
            // card5FrontpictureBox
            // 
            this.card5FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5FrontpictureBox.Image")));
            this.card5FrontpictureBox.Location = new System.Drawing.Point(420, 12);
            this.card5FrontpictureBox.Name = "card5FrontpictureBox";
            this.card5FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card5FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5FrontpictureBox.TabIndex = 60;
            this.card5FrontpictureBox.TabStop = false;
            // 
            // card4FrontpictureBox
            // 
            this.card4FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4FrontpictureBox.Image")));
            this.card4FrontpictureBox.Location = new System.Drawing.Point(318, 12);
            this.card4FrontpictureBox.Name = "card4FrontpictureBox";
            this.card4FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card4FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4FrontpictureBox.TabIndex = 59;
            this.card4FrontpictureBox.TabStop = false;
            // 
            // card3FrontpictureBox
            // 
            this.card3FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3FrontpictureBox.Image")));
            this.card3FrontpictureBox.Location = new System.Drawing.Point(216, 12);
            this.card3FrontpictureBox.Name = "card3FrontpictureBox";
            this.card3FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card3FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3FrontpictureBox.TabIndex = 58;
            this.card3FrontpictureBox.TabStop = false;
            // 
            // card2FrontpictureBox
            // 
            this.card2FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2FrontpictureBox.Image")));
            this.card2FrontpictureBox.Location = new System.Drawing.Point(114, 12);
            this.card2FrontpictureBox.Name = "card2FrontpictureBox";
            this.card2FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card2FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2FrontpictureBox.TabIndex = 57;
            this.card2FrontpictureBox.TabStop = false;
            // 
            // card1FrontpictureBox
            // 
            this.card1FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1FrontpictureBox.Image")));
            this.card1FrontpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1FrontpictureBox.Name = "card1FrontpictureBox";
            this.card1FrontpictureBox.Size = new System.Drawing.Size(96, 96);
            this.card1FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1FrontpictureBox.TabIndex = 56;
            this.card1FrontpictureBox.TabStop = false;
            // 
            // Level_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 423);
            this.Controls.Add(this.card20BackpictureBox);
            this.Controls.Add(this.card19BackpictureBox);
            this.Controls.Add(this.card18BackpictureBox);
            this.Controls.Add(this.card17BackpictureBox);
            this.Controls.Add(this.card16BackpictureBox);
            this.Controls.Add(this.card15BackpictureBox);
            this.Controls.Add(this.card14BackpictureBox);
            this.Controls.Add(this.card13BackpictureBox);
            this.Controls.Add(this.card12BackpictureBox);
            this.Controls.Add(this.card11BackpictureBox);
            this.Controls.Add(this.card10BackpictureBox);
            this.Controls.Add(this.card9BackpictureBox);
            this.Controls.Add(this.card8BackpictureBox);
            this.Controls.Add(this.card7BackpictureBox);
            this.Controls.Add(this.card6BackpictureBox);
            this.Controls.Add(this.card5BackpictureBox);
            this.Controls.Add(this.card4BackpictureBox);
            this.Controls.Add(this.card3BackpictureBox);
            this.Controls.Add(this.card2BackpictureBox);
            this.Controls.Add(this.card1BackpictureBox);
            this.Controls.Add(this.card20FrontpictureBox);
            this.Controls.Add(this.card19FrontpictureBox);
            this.Controls.Add(this.card18FrontpictureBox);
            this.Controls.Add(this.card17FrontpictureBox);
            this.Controls.Add(this.card16FrontpictureBox);
            this.Controls.Add(this.card15FrontpictureBox);
            this.Controls.Add(this.card14FrontpictureBox);
            this.Controls.Add(this.card13FrontpictureBox);
            this.Controls.Add(this.card12FrontpictureBox);
            this.Controls.Add(this.card11FrontpictureBox);
            this.Controls.Add(this.card10FrontpictureBox);
            this.Controls.Add(this.card9FrontpictureBox);
            this.Controls.Add(this.card8FrontpictureBox);
            this.Controls.Add(this.card7FrontpictureBox);
            this.Controls.Add(this.card6FrontpictureBox);
            this.Controls.Add(this.card5FrontpictureBox);
            this.Controls.Add(this.card4FrontpictureBox);
            this.Controls.Add(this.card3FrontpictureBox);
            this.Controls.Add(this.card2FrontpictureBox);
            this.Controls.Add(this.card1FrontpictureBox);
            this.Name = "Level_2";
            this.Text = "Level_2";
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card20FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card16FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox card12BackpictureBox;
        private System.Windows.Forms.PictureBox card11BackpictureBox;
        private System.Windows.Forms.PictureBox card10BackpictureBox;
        private System.Windows.Forms.PictureBox card9BackpictureBox;
        private System.Windows.Forms.PictureBox card8BackpictureBox;
        private System.Windows.Forms.PictureBox card7BackpictureBox;
        private System.Windows.Forms.PictureBox card6BackpictureBox;
        private System.Windows.Forms.PictureBox card5BackpictureBox;
        private System.Windows.Forms.PictureBox card4BackpictureBox;
        private System.Windows.Forms.PictureBox card3BackpictureBox;
        private System.Windows.Forms.PictureBox card2BackpictureBox;
        private System.Windows.Forms.PictureBox card1BackpictureBox;
        private System.Windows.Forms.PictureBox card14BackpictureBox;
        private System.Windows.Forms.PictureBox card13BackpictureBox;
        private System.Windows.Forms.PictureBox card15BackpictureBox;
        private System.Windows.Forms.PictureBox card20BackpictureBox;
        private System.Windows.Forms.PictureBox card19BackpictureBox;
        private System.Windows.Forms.PictureBox card18BackpictureBox;
        private System.Windows.Forms.PictureBox card17BackpictureBox;
        private System.Windows.Forms.PictureBox card16BackpictureBox;
        private System.Windows.Forms.PictureBox card20FrontpictureBox;
        private System.Windows.Forms.PictureBox card19FrontpictureBox;
        private System.Windows.Forms.PictureBox card18FrontpictureBox;
        private System.Windows.Forms.PictureBox card17FrontpictureBox;
        private System.Windows.Forms.PictureBox card16FrontpictureBox;
        private System.Windows.Forms.PictureBox card15FrontpictureBox;
        private System.Windows.Forms.PictureBox card14FrontpictureBox;
        private System.Windows.Forms.PictureBox card13FrontpictureBox;
        private System.Windows.Forms.PictureBox card12FrontpictureBox;
        private System.Windows.Forms.PictureBox card11FrontpictureBox;
        private System.Windows.Forms.PictureBox card10FrontpictureBox;
        private System.Windows.Forms.PictureBox card9FrontpictureBox;
        private System.Windows.Forms.PictureBox card8FrontpictureBox;
        private System.Windows.Forms.PictureBox card7FrontpictureBox;
        private System.Windows.Forms.PictureBox card6FrontpictureBox;
        private System.Windows.Forms.PictureBox card5FrontpictureBox;
        private System.Windows.Forms.PictureBox card4FrontpictureBox;
        private System.Windows.Forms.PictureBox card3FrontpictureBox;
        private System.Windows.Forms.PictureBox card2FrontpictureBox;
        private System.Windows.Forms.PictureBox card1FrontpictureBox;
    }
}