﻿namespace Witters_HW11_MatchingGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.card1BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card2BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card3BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card4BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card5BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card6BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card7BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card8BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card9BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card10BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card11BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card12BackpictureBox = new System.Windows.Forms.PictureBox();
            this.card12FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card11FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card10FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card9FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card8FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card7FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card6FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card5FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card4FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card3FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card2FrontpictureBox = new System.Windows.Forms.PictureBox();
            this.card1FrontpictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // card1BackpictureBox
            // 
            this.card1BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1BackpictureBox.Image")));
            this.card1BackpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1BackpictureBox.Name = "card1BackpictureBox";
            this.card1BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card1BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1BackpictureBox.TabIndex = 0;
            this.card1BackpictureBox.TabStop = false;
            this.card1BackpictureBox.Click += new System.EventHandler(this.card1BackpictureBox_Click);
            // 
            // card2BackpictureBox
            // 
            this.card2BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2BackpictureBox.Image")));
            this.card2BackpictureBox.Location = new System.Drawing.Point(146, 12);
            this.card2BackpictureBox.Name = "card2BackpictureBox";
            this.card2BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card2BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2BackpictureBox.TabIndex = 1;
            this.card2BackpictureBox.TabStop = false;
            this.card2BackpictureBox.Click += new System.EventHandler(this.card2BackpictureBox_Click);
            // 
            // card3BackpictureBox
            // 
            this.card3BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3BackpictureBox.Image")));
            this.card3BackpictureBox.Location = new System.Drawing.Point(280, 12);
            this.card3BackpictureBox.Name = "card3BackpictureBox";
            this.card3BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card3BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3BackpictureBox.TabIndex = 2;
            this.card3BackpictureBox.TabStop = false;
            this.card3BackpictureBox.Click += new System.EventHandler(this.card3BackpictureBox_Click);
            // 
            // card4BackpictureBox
            // 
            this.card4BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4BackpictureBox.Image")));
            this.card4BackpictureBox.Location = new System.Drawing.Point(414, 12);
            this.card4BackpictureBox.Name = "card4BackpictureBox";
            this.card4BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card4BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4BackpictureBox.TabIndex = 3;
            this.card4BackpictureBox.TabStop = false;
            this.card4BackpictureBox.Click += new System.EventHandler(this.card4BackpictureBox_Click);
            // 
            // card5BackpictureBox
            // 
            this.card5BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5BackpictureBox.Image")));
            this.card5BackpictureBox.Location = new System.Drawing.Point(12, 146);
            this.card5BackpictureBox.Name = "card5BackpictureBox";
            this.card5BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card5BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5BackpictureBox.TabIndex = 4;
            this.card5BackpictureBox.TabStop = false;
            this.card5BackpictureBox.Click += new System.EventHandler(this.card5BackpictureBox_Click);
            // 
            // card6BackpictureBox
            // 
            this.card6BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6BackpictureBox.Image")));
            this.card6BackpictureBox.Location = new System.Drawing.Point(146, 146);
            this.card6BackpictureBox.Name = "card6BackpictureBox";
            this.card6BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card6BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6BackpictureBox.TabIndex = 5;
            this.card6BackpictureBox.TabStop = false;
            this.card6BackpictureBox.Click += new System.EventHandler(this.card6BackpictureBox_Click);
            // 
            // card7BackpictureBox
            // 
            this.card7BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7BackpictureBox.Image")));
            this.card7BackpictureBox.Location = new System.Drawing.Point(280, 146);
            this.card7BackpictureBox.Name = "card7BackpictureBox";
            this.card7BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card7BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7BackpictureBox.TabIndex = 6;
            this.card7BackpictureBox.TabStop = false;
            this.card7BackpictureBox.Click += new System.EventHandler(this.card7BackpictureBox_Click);
            // 
            // card8BackpictureBox
            // 
            this.card8BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8BackpictureBox.Image")));
            this.card8BackpictureBox.Location = new System.Drawing.Point(414, 146);
            this.card8BackpictureBox.Name = "card8BackpictureBox";
            this.card8BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card8BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8BackpictureBox.TabIndex = 7;
            this.card8BackpictureBox.TabStop = false;
            this.card8BackpictureBox.Click += new System.EventHandler(this.card8BackpictureBox_Click);
            // 
            // card9BackpictureBox
            // 
            this.card9BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9BackpictureBox.Image")));
            this.card9BackpictureBox.Location = new System.Drawing.Point(12, 280);
            this.card9BackpictureBox.Name = "card9BackpictureBox";
            this.card9BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card9BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9BackpictureBox.TabIndex = 8;
            this.card9BackpictureBox.TabStop = false;
            this.card9BackpictureBox.Click += new System.EventHandler(this.card9BackpictureBox_Click);
            // 
            // card10BackpictureBox
            // 
            this.card10BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10BackpictureBox.Image")));
            this.card10BackpictureBox.Location = new System.Drawing.Point(146, 280);
            this.card10BackpictureBox.Name = "card10BackpictureBox";
            this.card10BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card10BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10BackpictureBox.TabIndex = 9;
            this.card10BackpictureBox.TabStop = false;
            this.card10BackpictureBox.Click += new System.EventHandler(this.card10BackpictureBox_Click);
            // 
            // card11BackpictureBox
            // 
            this.card11BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11BackpictureBox.Image")));
            this.card11BackpictureBox.Location = new System.Drawing.Point(280, 280);
            this.card11BackpictureBox.Name = "card11BackpictureBox";
            this.card11BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card11BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11BackpictureBox.TabIndex = 10;
            this.card11BackpictureBox.TabStop = false;
            this.card11BackpictureBox.Click += new System.EventHandler(this.card11BackpictureBox_Click);
            // 
            // card12BackpictureBox
            // 
            this.card12BackpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12BackpictureBox.Image")));
            this.card12BackpictureBox.Location = new System.Drawing.Point(414, 280);
            this.card12BackpictureBox.Name = "card12BackpictureBox";
            this.card12BackpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card12BackpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12BackpictureBox.TabIndex = 11;
            this.card12BackpictureBox.TabStop = false;
            this.card12BackpictureBox.Click += new System.EventHandler(this.card12BackpictureBox_Click);
            // 
            // card12FrontpictureBox
            // 
            this.card12FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card12FrontpictureBox.Image")));
            this.card12FrontpictureBox.Location = new System.Drawing.Point(414, 280);
            this.card12FrontpictureBox.Name = "card12FrontpictureBox";
            this.card12FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card12FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card12FrontpictureBox.TabIndex = 23;
            this.card12FrontpictureBox.TabStop = false;
            this.card12FrontpictureBox.Visible = false;
            // 
            // card11FrontpictureBox
            // 
            this.card11FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card11FrontpictureBox.Image")));
            this.card11FrontpictureBox.Location = new System.Drawing.Point(280, 280);
            this.card11FrontpictureBox.Name = "card11FrontpictureBox";
            this.card11FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card11FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card11FrontpictureBox.TabIndex = 22;
            this.card11FrontpictureBox.TabStop = false;
            this.card11FrontpictureBox.Visible = false;
            // 
            // card10FrontpictureBox
            // 
            this.card10FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card10FrontpictureBox.Image")));
            this.card10FrontpictureBox.Location = new System.Drawing.Point(146, 280);
            this.card10FrontpictureBox.Name = "card10FrontpictureBox";
            this.card10FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card10FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card10FrontpictureBox.TabIndex = 21;
            this.card10FrontpictureBox.TabStop = false;
            this.card10FrontpictureBox.Visible = false;
            // 
            // card9FrontpictureBox
            // 
            this.card9FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card9FrontpictureBox.Image")));
            this.card9FrontpictureBox.Location = new System.Drawing.Point(12, 280);
            this.card9FrontpictureBox.Name = "card9FrontpictureBox";
            this.card9FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card9FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card9FrontpictureBox.TabIndex = 20;
            this.card9FrontpictureBox.TabStop = false;
            this.card9FrontpictureBox.Visible = false;
            // 
            // card8FrontpictureBox
            // 
            this.card8FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card8FrontpictureBox.Image")));
            this.card8FrontpictureBox.Location = new System.Drawing.Point(414, 146);
            this.card8FrontpictureBox.Name = "card8FrontpictureBox";
            this.card8FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card8FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card8FrontpictureBox.TabIndex = 19;
            this.card8FrontpictureBox.TabStop = false;
            this.card8FrontpictureBox.Visible = false;
            // 
            // card7FrontpictureBox
            // 
            this.card7FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card7FrontpictureBox.Image")));
            this.card7FrontpictureBox.Location = new System.Drawing.Point(280, 146);
            this.card7FrontpictureBox.Name = "card7FrontpictureBox";
            this.card7FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card7FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card7FrontpictureBox.TabIndex = 18;
            this.card7FrontpictureBox.TabStop = false;
            this.card7FrontpictureBox.Visible = false;
            // 
            // card6FrontpictureBox
            // 
            this.card6FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card6FrontpictureBox.Image")));
            this.card6FrontpictureBox.Location = new System.Drawing.Point(146, 146);
            this.card6FrontpictureBox.Name = "card6FrontpictureBox";
            this.card6FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card6FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card6FrontpictureBox.TabIndex = 17;
            this.card6FrontpictureBox.TabStop = false;
            this.card6FrontpictureBox.Visible = false;
            // 
            // card5FrontpictureBox
            // 
            this.card5FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card5FrontpictureBox.Image")));
            this.card5FrontpictureBox.Location = new System.Drawing.Point(12, 146);
            this.card5FrontpictureBox.Name = "card5FrontpictureBox";
            this.card5FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card5FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card5FrontpictureBox.TabIndex = 16;
            this.card5FrontpictureBox.TabStop = false;
            this.card5FrontpictureBox.Visible = false;
            // 
            // card4FrontpictureBox
            // 
            this.card4FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card4FrontpictureBox.Image")));
            this.card4FrontpictureBox.Location = new System.Drawing.Point(414, 12);
            this.card4FrontpictureBox.Name = "card4FrontpictureBox";
            this.card4FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card4FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card4FrontpictureBox.TabIndex = 15;
            this.card4FrontpictureBox.TabStop = false;
            this.card4FrontpictureBox.Visible = false;
            // 
            // card3FrontpictureBox
            // 
            this.card3FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card3FrontpictureBox.Image")));
            this.card3FrontpictureBox.Location = new System.Drawing.Point(280, 12);
            this.card3FrontpictureBox.Name = "card3FrontpictureBox";
            this.card3FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card3FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card3FrontpictureBox.TabIndex = 14;
            this.card3FrontpictureBox.TabStop = false;
            this.card3FrontpictureBox.Visible = false;
            // 
            // card2FrontpictureBox
            // 
            this.card2FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card2FrontpictureBox.Image")));
            this.card2FrontpictureBox.Location = new System.Drawing.Point(146, 12);
            this.card2FrontpictureBox.Name = "card2FrontpictureBox";
            this.card2FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card2FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card2FrontpictureBox.TabIndex = 13;
            this.card2FrontpictureBox.TabStop = false;
            this.card2FrontpictureBox.Visible = false;
            // 
            // card1FrontpictureBox
            // 
            this.card1FrontpictureBox.Image = ((System.Drawing.Image)(resources.GetObject("card1FrontpictureBox.Image")));
            this.card1FrontpictureBox.Location = new System.Drawing.Point(12, 12);
            this.card1FrontpictureBox.Name = "card1FrontpictureBox";
            this.card1FrontpictureBox.Size = new System.Drawing.Size(128, 128);
            this.card1FrontpictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.card1FrontpictureBox.TabIndex = 12;
            this.card1FrontpictureBox.TabStop = false;
            this.card1FrontpictureBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 414);
            this.Controls.Add(this.card12BackpictureBox);
            this.Controls.Add(this.card11BackpictureBox);
            this.Controls.Add(this.card10BackpictureBox);
            this.Controls.Add(this.card9BackpictureBox);
            this.Controls.Add(this.card8BackpictureBox);
            this.Controls.Add(this.card7BackpictureBox);
            this.Controls.Add(this.card6BackpictureBox);
            this.Controls.Add(this.card5BackpictureBox);
            this.Controls.Add(this.card4BackpictureBox);
            this.Controls.Add(this.card3BackpictureBox);
            this.Controls.Add(this.card2BackpictureBox);
            this.Controls.Add(this.card1BackpictureBox);
            this.Controls.Add(this.card12FrontpictureBox);
            this.Controls.Add(this.card11FrontpictureBox);
            this.Controls.Add(this.card10FrontpictureBox);
            this.Controls.Add(this.card9FrontpictureBox);
            this.Controls.Add(this.card8FrontpictureBox);
            this.Controls.Add(this.card7FrontpictureBox);
            this.Controls.Add(this.card6FrontpictureBox);
            this.Controls.Add(this.card5FrontpictureBox);
            this.Controls.Add(this.card4FrontpictureBox);
            this.Controls.Add(this.card3FrontpictureBox);
            this.Controls.Add(this.card2FrontpictureBox);
            this.Controls.Add(this.card1FrontpictureBox);
            this.Name = "Form1";
            this.Text = "Matching Game";
            ((System.ComponentModel.ISupportInitialize)(this.card1BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12BackpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2FrontpictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1FrontpictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox card1BackpictureBox;
        private System.Windows.Forms.PictureBox card2BackpictureBox;
        private System.Windows.Forms.PictureBox card3BackpictureBox;
        private System.Windows.Forms.PictureBox card4BackpictureBox;
        private System.Windows.Forms.PictureBox card5BackpictureBox;
        private System.Windows.Forms.PictureBox card6BackpictureBox;
        private System.Windows.Forms.PictureBox card7BackpictureBox;
        private System.Windows.Forms.PictureBox card8BackpictureBox;
        private System.Windows.Forms.PictureBox card9BackpictureBox;
        private System.Windows.Forms.PictureBox card10BackpictureBox;
        private System.Windows.Forms.PictureBox card11BackpictureBox;
        private System.Windows.Forms.PictureBox card12BackpictureBox;
        private System.Windows.Forms.PictureBox card12FrontpictureBox;
        private System.Windows.Forms.PictureBox card11FrontpictureBox;
        private System.Windows.Forms.PictureBox card10FrontpictureBox;
        private System.Windows.Forms.PictureBox card9FrontpictureBox;
        private System.Windows.Forms.PictureBox card8FrontpictureBox;
        private System.Windows.Forms.PictureBox card7FrontpictureBox;
        private System.Windows.Forms.PictureBox card6FrontpictureBox;
        private System.Windows.Forms.PictureBox card5FrontpictureBox;
        private System.Windows.Forms.PictureBox card4FrontpictureBox;
        private System.Windows.Forms.PictureBox card3FrontpictureBox;
        private System.Windows.Forms.PictureBox card2FrontpictureBox;
        private System.Windows.Forms.PictureBox card1FrontpictureBox;
    }
}

