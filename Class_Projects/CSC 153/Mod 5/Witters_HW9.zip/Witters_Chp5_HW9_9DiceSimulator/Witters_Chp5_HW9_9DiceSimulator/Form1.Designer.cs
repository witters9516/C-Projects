﻿namespace Witters_Chp5_HW9_9DiceSimulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dice1PictureBox = new System.Windows.Forms.PictureBox();
            this.dice12PictureBox = new System.Windows.Forms.PictureBox();
            this.rollDiceButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.dice7PictureBox = new System.Windows.Forms.PictureBox();
            this.dice8PictureBox = new System.Windows.Forms.PictureBox();
            this.dice9PictureBox = new System.Windows.Forms.PictureBox();
            this.dice10PictureBox = new System.Windows.Forms.PictureBox();
            this.dice11PictureBox = new System.Windows.Forms.PictureBox();
            this.dice2PictureBox = new System.Windows.Forms.PictureBox();
            this.dice3PictureBox = new System.Windows.Forms.PictureBox();
            this.dice4PictureBox = new System.Windows.Forms.PictureBox();
            this.dice5PictureBox = new System.Windows.Forms.PictureBox();
            this.dice6PictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dice1PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice12PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice7PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice8PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice9PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice10PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice11PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice3PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice4PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice5PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice6PictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // dice1PictureBox
            // 
            this.dice1PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice1PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_1;
            this.dice1PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice1PictureBox.Name = "dice1PictureBox";
            this.dice1PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice1PictureBox.TabIndex = 1;
            this.dice1PictureBox.TabStop = false;
            this.dice1PictureBox.Visible = false;
            // 
            // dice12PictureBox
            // 
            this.dice12PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice12PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_6;
            this.dice12PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice12PictureBox.Name = "dice12PictureBox";
            this.dice12PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice12PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice12PictureBox.TabIndex = 2;
            this.dice12PictureBox.TabStop = false;
            this.dice12PictureBox.Visible = false;
            // 
            // rollDiceButton
            // 
            this.rollDiceButton.Location = new System.Drawing.Point(12, 119);
            this.rollDiceButton.Name = "rollDiceButton";
            this.rollDiceButton.Size = new System.Drawing.Size(101, 23);
            this.rollDiceButton.TabIndex = 3;
            this.rollDiceButton.Text = "Roll Dice";
            this.rollDiceButton.UseVisualStyleBackColor = true;
            this.rollDiceButton.Click += new System.EventHandler(this.rollDiceButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(119, 119);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(100, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // dice7PictureBox
            // 
            this.dice7PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice7PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_1;
            this.dice7PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice7PictureBox.Name = "dice7PictureBox";
            this.dice7PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice7PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice7PictureBox.TabIndex = 5;
            this.dice7PictureBox.TabStop = false;
            this.dice7PictureBox.Visible = false;
            // 
            // dice8PictureBox
            // 
            this.dice8PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice8PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_2;
            this.dice8PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice8PictureBox.Name = "dice8PictureBox";
            this.dice8PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice8PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice8PictureBox.TabIndex = 6;
            this.dice8PictureBox.TabStop = false;
            this.dice8PictureBox.Visible = false;
            // 
            // dice9PictureBox
            // 
            this.dice9PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice9PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_3;
            this.dice9PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice9PictureBox.Name = "dice9PictureBox";
            this.dice9PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice9PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice9PictureBox.TabIndex = 7;
            this.dice9PictureBox.TabStop = false;
            this.dice9PictureBox.Visible = false;
            // 
            // dice10PictureBox
            // 
            this.dice10PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice10PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_4;
            this.dice10PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice10PictureBox.Name = "dice10PictureBox";
            this.dice10PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice10PictureBox.TabIndex = 8;
            this.dice10PictureBox.TabStop = false;
            this.dice10PictureBox.Visible = false;
            // 
            // dice11PictureBox
            // 
            this.dice11PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice11PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_5;
            this.dice11PictureBox.Location = new System.Drawing.Point(118, 7);
            this.dice11PictureBox.Name = "dice11PictureBox";
            this.dice11PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice11PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice11PictureBox.TabIndex = 9;
            this.dice11PictureBox.TabStop = false;
            this.dice11PictureBox.Visible = false;
            // 
            // dice2PictureBox
            // 
            this.dice2PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice2PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_2;
            this.dice2PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice2PictureBox.Name = "dice2PictureBox";
            this.dice2PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice2PictureBox.TabIndex = 10;
            this.dice2PictureBox.TabStop = false;
            this.dice2PictureBox.Visible = false;
            // 
            // dice3PictureBox
            // 
            this.dice3PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice3PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_3;
            this.dice3PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice3PictureBox.Name = "dice3PictureBox";
            this.dice3PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice3PictureBox.TabIndex = 11;
            this.dice3PictureBox.TabStop = false;
            this.dice3PictureBox.Visible = false;
            // 
            // dice4PictureBox
            // 
            this.dice4PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice4PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_4;
            this.dice4PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice4PictureBox.Name = "dice4PictureBox";
            this.dice4PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice4PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice4PictureBox.TabIndex = 12;
            this.dice4PictureBox.TabStop = false;
            this.dice4PictureBox.Visible = false;
            // 
            // dice5PictureBox
            // 
            this.dice5PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice5PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_5;
            this.dice5PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice5PictureBox.Name = "dice5PictureBox";
            this.dice5PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice5PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice5PictureBox.TabIndex = 13;
            this.dice5PictureBox.TabStop = false;
            this.dice5PictureBox.Visible = false;
            // 
            // dice6PictureBox
            // 
            this.dice6PictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dice6PictureBox.Image = global::Witters_Chp5_HW9_9DiceSimulator.Properties.Resources.dice_side_6;
            this.dice6PictureBox.Location = new System.Drawing.Point(13, 7);
            this.dice6PictureBox.Name = "dice6PictureBox";
            this.dice6PictureBox.Size = new System.Drawing.Size(100, 106);
            this.dice6PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.dice6PictureBox.TabIndex = 14;
            this.dice6PictureBox.TabStop = false;
            this.dice6PictureBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(224, 149);
            this.Controls.Add(this.dice6PictureBox);
            this.Controls.Add(this.dice5PictureBox);
            this.Controls.Add(this.dice4PictureBox);
            this.Controls.Add(this.dice3PictureBox);
            this.Controls.Add(this.dice2PictureBox);
            this.Controls.Add(this.dice9PictureBox);
            this.Controls.Add(this.dice8PictureBox);
            this.Controls.Add(this.dice7PictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollDiceButton);
            this.Controls.Add(this.dice12PictureBox);
            this.Controls.Add(this.dice1PictureBox);
            this.Controls.Add(this.dice11PictureBox);
            this.Controls.Add(this.dice10PictureBox);
            this.Name = "Form1";
            this.Text = "Dice Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.dice1PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice12PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice7PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice8PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice9PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice10PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice11PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice3PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice4PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice5PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dice6PictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox dice1PictureBox;
        private System.Windows.Forms.PictureBox dice12PictureBox;
        private System.Windows.Forms.Button rollDiceButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox dice7PictureBox;
        private System.Windows.Forms.PictureBox dice8PictureBox;
        private System.Windows.Forms.PictureBox dice9PictureBox;
        private System.Windows.Forms.PictureBox dice10PictureBox;
        private System.Windows.Forms.PictureBox dice11PictureBox;
        private System.Windows.Forms.PictureBox dice2PictureBox;
        private System.Windows.Forms.PictureBox dice3PictureBox;
        private System.Windows.Forms.PictureBox dice4PictureBox;
        private System.Windows.Forms.PictureBox dice5PictureBox;
        private System.Windows.Forms.PictureBox dice6PictureBox;
    }
}

