﻿// This program asks the user to update their information by inputing it into the text boxes. 
//When the user clicks submit the program creates a new message box to tell the user what their information is. 
//If the cancel button is pressed, the program exits.
// 1/20/17
// CSC 153 0001
// Shawn Witter

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Witters_Mod2_GradedLab
{
    public partial class updateInformation : Form
    {
        public updateInformation()
        {
            InitializeComponent();
        }

        private void submitButton_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you. Your information has been updated.\n" +
                "\t\t" +
                nameTextbox.Text +
                "\n\t\t" +
                birthdayTextbox.Text +
                "\n\t\t" +
                emailTextbox.Text);
            this.Close();
        }

        private void cancelButton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
