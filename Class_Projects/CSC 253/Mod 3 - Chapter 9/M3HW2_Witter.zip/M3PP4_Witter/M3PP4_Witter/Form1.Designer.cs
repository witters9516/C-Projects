﻿namespace M3PP4_Witter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel6 = new System.Windows.Forms.Panel();
            this.position3DisplayLabel = new System.Windows.Forms.Label();
            this.department3DisplayLabel = new System.Windows.Forms.Label();
            this.id3DisplayLabel = new System.Windows.Forms.Label();
            this.name3DisplayLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.output9DisplayLabel = new System.Windows.Forms.Label();
            this.output10DisplayLabel = new System.Windows.Forms.Label();
            this.output11DisplayLabel = new System.Windows.Forms.Label();
            this.output12DisplayLabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.position2DisplayLabel = new System.Windows.Forms.Label();
            this.department2DisplayLabel = new System.Windows.Forms.Label();
            this.id2DisplayLabel = new System.Windows.Forms.Label();
            this.name2DisplayLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.output5DisplayLabel = new System.Windows.Forms.Label();
            this.output6DisplayLabel = new System.Windows.Forms.Label();
            this.output7DisplayLabel = new System.Windows.Forms.Label();
            this.output8DisplayLabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.position1DisplayLabel = new System.Windows.Forms.Label();
            this.department1DisplayLabel = new System.Windows.Forms.Label();
            this.id1DisplayLabel = new System.Windows.Forms.Label();
            this.name1DisplayLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.output1DisplayLabel = new System.Windows.Forms.Label();
            this.output2DisplayLabel = new System.Windows.Forms.Label();
            this.output3DisplayLabel = new System.Windows.Forms.Label();
            this.output4DisplayLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.createPersonButton = new System.Windows.Forms.Button();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.position3DisplayLabel);
            this.panel6.Controls.Add(this.department3DisplayLabel);
            this.panel6.Controls.Add(this.id3DisplayLabel);
            this.panel6.Controls.Add(this.name3DisplayLabel);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.output9DisplayLabel);
            this.panel6.Controls.Add(this.output10DisplayLabel);
            this.panel6.Controls.Add(this.output11DisplayLabel);
            this.panel6.Controls.Add(this.output12DisplayLabel);
            this.panel6.Location = new System.Drawing.Point(12, 368);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(221, 172);
            this.panel6.TabIndex = 53;
            // 
            // position3DisplayLabel
            // 
            this.position3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.position3DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.position3DisplayLabel.Name = "position3DisplayLabel";
            this.position3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.position3DisplayLabel.TabIndex = 32;
            this.position3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // department3DisplayLabel
            // 
            this.department3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.department3DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.department3DisplayLabel.Name = "department3DisplayLabel";
            this.department3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.department3DisplayLabel.TabIndex = 31;
            this.department3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // id3DisplayLabel
            // 
            this.id3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.id3DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.id3DisplayLabel.Name = "id3DisplayLabel";
            this.id3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.id3DisplayLabel.TabIndex = 30;
            this.id3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name3DisplayLabel
            // 
            this.name3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name3DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name3DisplayLabel.Name = "name3DisplayLabel";
            this.name3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name3DisplayLabel.TabIndex = 29;
            this.name3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Employee 3:";
            // 
            // output9DisplayLabel
            // 
            this.output9DisplayLabel.AutoSize = true;
            this.output9DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output9DisplayLabel.Name = "output9DisplayLabel";
            this.output9DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output9DisplayLabel.TabIndex = 20;
            this.output9DisplayLabel.Text = "Name:";
            // 
            // output10DisplayLabel
            // 
            this.output10DisplayLabel.AutoSize = true;
            this.output10DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output10DisplayLabel.Name = "output10DisplayLabel";
            this.output10DisplayLabel.Size = new System.Drawing.Size(61, 13);
            this.output10DisplayLabel.TabIndex = 21;
            this.output10DisplayLabel.Text = "ID Number:";
            // 
            // output11DisplayLabel
            // 
            this.output11DisplayLabel.AutoSize = true;
            this.output11DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output11DisplayLabel.Name = "output11DisplayLabel";
            this.output11DisplayLabel.Size = new System.Drawing.Size(65, 13);
            this.output11DisplayLabel.TabIndex = 22;
            this.output11DisplayLabel.Text = "Department:";
            // 
            // output12DisplayLabel
            // 
            this.output12DisplayLabel.AutoSize = true;
            this.output12DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output12DisplayLabel.Name = "output12DisplayLabel";
            this.output12DisplayLabel.Size = new System.Drawing.Size(47, 13);
            this.output12DisplayLabel.TabIndex = 26;
            this.output12DisplayLabel.Text = "Position:";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.position2DisplayLabel);
            this.panel5.Controls.Add(this.department2DisplayLabel);
            this.panel5.Controls.Add(this.id2DisplayLabel);
            this.panel5.Controls.Add(this.name2DisplayLabel);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.output5DisplayLabel);
            this.panel5.Controls.Add(this.output6DisplayLabel);
            this.panel5.Controls.Add(this.output7DisplayLabel);
            this.panel5.Controls.Add(this.output8DisplayLabel);
            this.panel5.Location = new System.Drawing.Point(12, 190);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(221, 172);
            this.panel5.TabIndex = 52;
            // 
            // position2DisplayLabel
            // 
            this.position2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.position2DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.position2DisplayLabel.Name = "position2DisplayLabel";
            this.position2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.position2DisplayLabel.TabIndex = 32;
            this.position2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // department2DisplayLabel
            // 
            this.department2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.department2DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.department2DisplayLabel.Name = "department2DisplayLabel";
            this.department2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.department2DisplayLabel.TabIndex = 31;
            this.department2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // id2DisplayLabel
            // 
            this.id2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.id2DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.id2DisplayLabel.Name = "id2DisplayLabel";
            this.id2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.id2DisplayLabel.TabIndex = 30;
            this.id2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name2DisplayLabel
            // 
            this.name2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name2DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name2DisplayLabel.Name = "name2DisplayLabel";
            this.name2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name2DisplayLabel.TabIndex = 29;
            this.name2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Employee 2:";
            // 
            // output5DisplayLabel
            // 
            this.output5DisplayLabel.AutoSize = true;
            this.output5DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output5DisplayLabel.Name = "output5DisplayLabel";
            this.output5DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output5DisplayLabel.TabIndex = 20;
            this.output5DisplayLabel.Text = "Name:";
            // 
            // output6DisplayLabel
            // 
            this.output6DisplayLabel.AutoSize = true;
            this.output6DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output6DisplayLabel.Name = "output6DisplayLabel";
            this.output6DisplayLabel.Size = new System.Drawing.Size(61, 13);
            this.output6DisplayLabel.TabIndex = 21;
            this.output6DisplayLabel.Text = "ID Number:";
            // 
            // output7DisplayLabel
            // 
            this.output7DisplayLabel.AutoSize = true;
            this.output7DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output7DisplayLabel.Name = "output7DisplayLabel";
            this.output7DisplayLabel.Size = new System.Drawing.Size(65, 13);
            this.output7DisplayLabel.TabIndex = 22;
            this.output7DisplayLabel.Text = "Department:";
            // 
            // output8DisplayLabel
            // 
            this.output8DisplayLabel.AutoSize = true;
            this.output8DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output8DisplayLabel.Name = "output8DisplayLabel";
            this.output8DisplayLabel.Size = new System.Drawing.Size(47, 13);
            this.output8DisplayLabel.TabIndex = 26;
            this.output8DisplayLabel.Text = "Position:";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.position1DisplayLabel);
            this.panel4.Controls.Add(this.department1DisplayLabel);
            this.panel4.Controls.Add(this.id1DisplayLabel);
            this.panel4.Controls.Add(this.name1DisplayLabel);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.output1DisplayLabel);
            this.panel4.Controls.Add(this.output2DisplayLabel);
            this.panel4.Controls.Add(this.output3DisplayLabel);
            this.panel4.Controls.Add(this.output4DisplayLabel);
            this.panel4.Location = new System.Drawing.Point(12, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(221, 172);
            this.panel4.TabIndex = 51;
            // 
            // position1DisplayLabel
            // 
            this.position1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.position1DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.position1DisplayLabel.Name = "position1DisplayLabel";
            this.position1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.position1DisplayLabel.TabIndex = 32;
            this.position1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // department1DisplayLabel
            // 
            this.department1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.department1DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.department1DisplayLabel.Name = "department1DisplayLabel";
            this.department1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.department1DisplayLabel.TabIndex = 31;
            this.department1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // id1DisplayLabel
            // 
            this.id1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.id1DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.id1DisplayLabel.Name = "id1DisplayLabel";
            this.id1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.id1DisplayLabel.TabIndex = 30;
            this.id1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name1DisplayLabel
            // 
            this.name1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name1DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name1DisplayLabel.Name = "name1DisplayLabel";
            this.name1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name1DisplayLabel.TabIndex = 29;
            this.name1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Employee 1:";
            // 
            // output1DisplayLabel
            // 
            this.output1DisplayLabel.AutoSize = true;
            this.output1DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output1DisplayLabel.Name = "output1DisplayLabel";
            this.output1DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output1DisplayLabel.TabIndex = 20;
            this.output1DisplayLabel.Text = "Name:";
            // 
            // output2DisplayLabel
            // 
            this.output2DisplayLabel.AutoSize = true;
            this.output2DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output2DisplayLabel.Name = "output2DisplayLabel";
            this.output2DisplayLabel.Size = new System.Drawing.Size(61, 13);
            this.output2DisplayLabel.TabIndex = 21;
            this.output2DisplayLabel.Text = "ID Number:";
            // 
            // output3DisplayLabel
            // 
            this.output3DisplayLabel.AutoSize = true;
            this.output3DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output3DisplayLabel.Name = "output3DisplayLabel";
            this.output3DisplayLabel.Size = new System.Drawing.Size(65, 13);
            this.output3DisplayLabel.TabIndex = 22;
            this.output3DisplayLabel.Text = "Department:";
            // 
            // output4DisplayLabel
            // 
            this.output4DisplayLabel.AutoSize = true;
            this.output4DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output4DisplayLabel.Name = "output4DisplayLabel";
            this.output4DisplayLabel.Size = new System.Drawing.Size(47, 13);
            this.output4DisplayLabel.TabIndex = 26;
            this.output4DisplayLabel.Text = "Position:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(158, 546);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 36);
            this.exitButton.TabIndex = 55;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // createPersonButton
            // 
            this.createPersonButton.Location = new System.Drawing.Point(12, 546);
            this.createPersonButton.Name = "createPersonButton";
            this.createPersonButton.Size = new System.Drawing.Size(75, 36);
            this.createPersonButton.TabIndex = 54;
            this.createPersonButton.Text = "Create Employees";
            this.createPersonButton.UseVisualStyleBackColor = true;
            this.createPersonButton.Click += new System.EventHandler(this.createPersonButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 592);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createPersonButton);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label position3DisplayLabel;
        private System.Windows.Forms.Label department3DisplayLabel;
        private System.Windows.Forms.Label id3DisplayLabel;
        private System.Windows.Forms.Label name3DisplayLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label output9DisplayLabel;
        private System.Windows.Forms.Label output10DisplayLabel;
        private System.Windows.Forms.Label output11DisplayLabel;
        private System.Windows.Forms.Label output12DisplayLabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label position2DisplayLabel;
        private System.Windows.Forms.Label department2DisplayLabel;
        private System.Windows.Forms.Label id2DisplayLabel;
        private System.Windows.Forms.Label name2DisplayLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label output5DisplayLabel;
        private System.Windows.Forms.Label output6DisplayLabel;
        private System.Windows.Forms.Label output7DisplayLabel;
        private System.Windows.Forms.Label output8DisplayLabel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label position1DisplayLabel;
        private System.Windows.Forms.Label department1DisplayLabel;
        private System.Windows.Forms.Label id1DisplayLabel;
        private System.Windows.Forms.Label name1DisplayLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label output1DisplayLabel;
        private System.Windows.Forms.Label output2DisplayLabel;
        private System.Windows.Forms.Label output3DisplayLabel;
        private System.Windows.Forms.Label output4DisplayLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createPersonButton;
    }
}

