﻿namespace M3PP3_Witter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.age1TextBox = new System.Windows.Forms.TextBox();
            this.address1TextBox = new System.Windows.Forms.TextBox();
            this.name1TextBox = new System.Windows.Forms.TextBox();
            this.input3Label = new System.Windows.Forms.Label();
            this.input2Label = new System.Windows.Forms.Label();
            this.input1Label = new System.Windows.Forms.Label();
            this.phoneNumber1TextBox = new System.Windows.Forms.TextBox();
            this.input4Label = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.createPersonButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.object1Label = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.input5Label = new System.Windows.Forms.Label();
            this.input6Label = new System.Windows.Forms.Label();
            this.input7Label = new System.Windows.Forms.Label();
            this.input8Label = new System.Windows.Forms.Label();
            this.phoneNumber2TextBox = new System.Windows.Forms.TextBox();
            this.age2TextBox = new System.Windows.Forms.TextBox();
            this.address2TextBox = new System.Windows.Forms.TextBox();
            this.name2TextBox = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.input9Label = new System.Windows.Forms.Label();
            this.input10Label = new System.Windows.Forms.Label();
            this.input11Label = new System.Windows.Forms.Label();
            this.input12Label = new System.Windows.Forms.Label();
            this.phoneNumber3TextBox = new System.Windows.Forms.TextBox();
            this.age3TextBox = new System.Windows.Forms.TextBox();
            this.address3TextBox = new System.Windows.Forms.TextBox();
            this.name3TextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.phoneNumber1DisplayLabel = new System.Windows.Forms.Label();
            this.age1DisplayLabel = new System.Windows.Forms.Label();
            this.address1DisplayLabel = new System.Windows.Forms.Label();
            this.name1DisplayLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.output1DisplayLabel = new System.Windows.Forms.Label();
            this.output2DisplayLabel = new System.Windows.Forms.Label();
            this.output3DisplayLabel = new System.Windows.Forms.Label();
            this.output4DisplayLabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.phoneNumber2DisplayLabel = new System.Windows.Forms.Label();
            this.age2DisplayLabel = new System.Windows.Forms.Label();
            this.address2DisplayLabel = new System.Windows.Forms.Label();
            this.name2DisplayLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.output5DisplayLabel = new System.Windows.Forms.Label();
            this.output6DisplayLabel = new System.Windows.Forms.Label();
            this.output7DisplayLabel = new System.Windows.Forms.Label();
            this.output8DisplayLabel = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.phoneNumber3DisplayLabel = new System.Windows.Forms.Label();
            this.age3DisplayLabel = new System.Windows.Forms.Label();
            this.address3DisplayLabel = new System.Windows.Forms.Label();
            this.name3DisplayLabel = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.output9DisplayLabel = new System.Windows.Forms.Label();
            this.output10DisplayLabel = new System.Windows.Forms.Label();
            this.output11DisplayLabel = new System.Windows.Forms.Label();
            this.output12DisplayLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // age1TextBox
            // 
            this.age1TextBox.Location = new System.Drawing.Point(98, 88);
            this.age1TextBox.Name = "age1TextBox";
            this.age1TextBox.Size = new System.Drawing.Size(100, 20);
            this.age1TextBox.TabIndex = 25;
            // 
            // address1TextBox
            // 
            this.address1TextBox.Location = new System.Drawing.Point(98, 62);
            this.address1TextBox.Name = "address1TextBox";
            this.address1TextBox.Size = new System.Drawing.Size(100, 20);
            this.address1TextBox.TabIndex = 24;
            // 
            // name1TextBox
            // 
            this.name1TextBox.Location = new System.Drawing.Point(98, 36);
            this.name1TextBox.Name = "name1TextBox";
            this.name1TextBox.Size = new System.Drawing.Size(100, 20);
            this.name1TextBox.TabIndex = 23;
            // 
            // input3Label
            // 
            this.input3Label.AutoSize = true;
            this.input3Label.Location = new System.Drawing.Point(11, 91);
            this.input3Label.Name = "input3Label";
            this.input3Label.Size = new System.Drawing.Size(29, 13);
            this.input3Label.TabIndex = 22;
            this.input3Label.Text = "Age:";
            // 
            // input2Label
            // 
            this.input2Label.AutoSize = true;
            this.input2Label.Location = new System.Drawing.Point(11, 65);
            this.input2Label.Name = "input2Label";
            this.input2Label.Size = new System.Drawing.Size(48, 13);
            this.input2Label.TabIndex = 21;
            this.input2Label.Text = "Address:";
            // 
            // input1Label
            // 
            this.input1Label.AutoSize = true;
            this.input1Label.Location = new System.Drawing.Point(11, 39);
            this.input1Label.Name = "input1Label";
            this.input1Label.Size = new System.Drawing.Size(38, 13);
            this.input1Label.TabIndex = 20;
            this.input1Label.Text = "Name:";
            // 
            // phoneNumber1TextBox
            // 
            this.phoneNumber1TextBox.Location = new System.Drawing.Point(98, 114);
            this.phoneNumber1TextBox.Name = "phoneNumber1TextBox";
            this.phoneNumber1TextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneNumber1TextBox.TabIndex = 27;
            // 
            // input4Label
            // 
            this.input4Label.AutoSize = true;
            this.input4Label.Location = new System.Drawing.Point(11, 117);
            this.input4Label.Name = "input4Label";
            this.input4Label.Size = new System.Drawing.Size(81, 13);
            this.input4Label.TabIndex = 26;
            this.input4Label.Text = "Phone Number:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(356, 362);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 36);
            this.exitButton.TabIndex = 29;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // createPersonButton
            // 
            this.createPersonButton.Location = new System.Drawing.Point(247, 362);
            this.createPersonButton.Name = "createPersonButton";
            this.createPersonButton.Size = new System.Drawing.Size(75, 36);
            this.createPersonButton.TabIndex = 28;
            this.createPersonButton.Text = "Create People";
            this.createPersonButton.UseVisualStyleBackColor = true;
            this.createPersonButton.Click += new System.EventHandler(this.createPersonButton_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.object1Label);
            this.panel1.Controls.Add(this.input1Label);
            this.panel1.Controls.Add(this.input2Label);
            this.panel1.Controls.Add(this.input3Label);
            this.panel1.Controls.Add(this.input4Label);
            this.panel1.Controls.Add(this.phoneNumber1TextBox);
            this.panel1.Controls.Add(this.age1TextBox);
            this.panel1.Controls.Add(this.address1TextBox);
            this.panel1.Controls.Add(this.name1TextBox);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 146);
            this.panel1.TabIndex = 46;
            // 
            // object1Label
            // 
            this.object1Label.AutoSize = true;
            this.object1Label.Location = new System.Drawing.Point(11, 11);
            this.object1Label.Name = "object1Label";
            this.object1Label.Size = new System.Drawing.Size(52, 13);
            this.object1Label.TabIndex = 28;
            this.object1Label.Text = "Person 1:";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.input5Label);
            this.panel2.Controls.Add(this.input6Label);
            this.panel2.Controls.Add(this.input7Label);
            this.panel2.Controls.Add(this.input8Label);
            this.panel2.Controls.Add(this.phoneNumber2TextBox);
            this.panel2.Controls.Add(this.age2TextBox);
            this.panel2.Controls.Add(this.address2TextBox);
            this.panel2.Controls.Add(this.name2TextBox);
            this.panel2.Location = new System.Drawing.Point(232, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(214, 146);
            this.panel2.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Person 2:";
            // 
            // input5Label
            // 
            this.input5Label.AutoSize = true;
            this.input5Label.Location = new System.Drawing.Point(11, 39);
            this.input5Label.Name = "input5Label";
            this.input5Label.Size = new System.Drawing.Size(38, 13);
            this.input5Label.TabIndex = 20;
            this.input5Label.Text = "Name:";
            // 
            // input6Label
            // 
            this.input6Label.AutoSize = true;
            this.input6Label.Location = new System.Drawing.Point(11, 65);
            this.input6Label.Name = "input6Label";
            this.input6Label.Size = new System.Drawing.Size(48, 13);
            this.input6Label.TabIndex = 21;
            this.input6Label.Text = "Address:";
            // 
            // input7Label
            // 
            this.input7Label.AutoSize = true;
            this.input7Label.Location = new System.Drawing.Point(11, 91);
            this.input7Label.Name = "input7Label";
            this.input7Label.Size = new System.Drawing.Size(29, 13);
            this.input7Label.TabIndex = 22;
            this.input7Label.Text = "Age:";
            // 
            // input8Label
            // 
            this.input8Label.AutoSize = true;
            this.input8Label.Location = new System.Drawing.Point(11, 117);
            this.input8Label.Name = "input8Label";
            this.input8Label.Size = new System.Drawing.Size(81, 13);
            this.input8Label.TabIndex = 26;
            this.input8Label.Text = "Phone Number:";
            // 
            // phoneNumber2TextBox
            // 
            this.phoneNumber2TextBox.Location = new System.Drawing.Point(98, 114);
            this.phoneNumber2TextBox.Name = "phoneNumber2TextBox";
            this.phoneNumber2TextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneNumber2TextBox.TabIndex = 27;
            // 
            // age2TextBox
            // 
            this.age2TextBox.Location = new System.Drawing.Point(98, 88);
            this.age2TextBox.Name = "age2TextBox";
            this.age2TextBox.Size = new System.Drawing.Size(100, 20);
            this.age2TextBox.TabIndex = 25;
            // 
            // address2TextBox
            // 
            this.address2TextBox.Location = new System.Drawing.Point(98, 62);
            this.address2TextBox.Name = "address2TextBox";
            this.address2TextBox.Size = new System.Drawing.Size(100, 20);
            this.address2TextBox.TabIndex = 24;
            // 
            // name2TextBox
            // 
            this.name2TextBox.Location = new System.Drawing.Point(98, 36);
            this.name2TextBox.Name = "name2TextBox";
            this.name2TextBox.Size = new System.Drawing.Size(100, 20);
            this.name2TextBox.TabIndex = 23;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.input9Label);
            this.panel3.Controls.Add(this.input10Label);
            this.panel3.Controls.Add(this.input11Label);
            this.panel3.Controls.Add(this.input12Label);
            this.panel3.Controls.Add(this.phoneNumber3TextBox);
            this.panel3.Controls.Add(this.age3TextBox);
            this.panel3.Controls.Add(this.address3TextBox);
            this.panel3.Controls.Add(this.name3TextBox);
            this.panel3.Location = new System.Drawing.Point(452, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(214, 146);
            this.panel3.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Person 3:";
            // 
            // input9Label
            // 
            this.input9Label.AutoSize = true;
            this.input9Label.Location = new System.Drawing.Point(11, 39);
            this.input9Label.Name = "input9Label";
            this.input9Label.Size = new System.Drawing.Size(38, 13);
            this.input9Label.TabIndex = 20;
            this.input9Label.Text = "Name:";
            // 
            // input10Label
            // 
            this.input10Label.AutoSize = true;
            this.input10Label.Location = new System.Drawing.Point(11, 65);
            this.input10Label.Name = "input10Label";
            this.input10Label.Size = new System.Drawing.Size(48, 13);
            this.input10Label.TabIndex = 21;
            this.input10Label.Text = "Address:";
            // 
            // input11Label
            // 
            this.input11Label.AutoSize = true;
            this.input11Label.Location = new System.Drawing.Point(11, 91);
            this.input11Label.Name = "input11Label";
            this.input11Label.Size = new System.Drawing.Size(29, 13);
            this.input11Label.TabIndex = 22;
            this.input11Label.Text = "Age:";
            // 
            // input12Label
            // 
            this.input12Label.AutoSize = true;
            this.input12Label.Location = new System.Drawing.Point(11, 117);
            this.input12Label.Name = "input12Label";
            this.input12Label.Size = new System.Drawing.Size(81, 13);
            this.input12Label.TabIndex = 26;
            this.input12Label.Text = "Phone Number:";
            // 
            // phoneNumber3TextBox
            // 
            this.phoneNumber3TextBox.Location = new System.Drawing.Point(98, 114);
            this.phoneNumber3TextBox.Name = "phoneNumber3TextBox";
            this.phoneNumber3TextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneNumber3TextBox.TabIndex = 27;
            // 
            // age3TextBox
            // 
            this.age3TextBox.Location = new System.Drawing.Point(98, 88);
            this.age3TextBox.Name = "age3TextBox";
            this.age3TextBox.Size = new System.Drawing.Size(100, 20);
            this.age3TextBox.TabIndex = 25;
            // 
            // address3TextBox
            // 
            this.address3TextBox.Location = new System.Drawing.Point(98, 62);
            this.address3TextBox.Name = "address3TextBox";
            this.address3TextBox.Size = new System.Drawing.Size(100, 20);
            this.address3TextBox.TabIndex = 24;
            // 
            // name3TextBox
            // 
            this.name3TextBox.Location = new System.Drawing.Point(98, 36);
            this.name3TextBox.Name = "name3TextBox";
            this.name3TextBox.Size = new System.Drawing.Size(100, 20);
            this.name3TextBox.TabIndex = 23;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.phoneNumber1DisplayLabel);
            this.panel4.Controls.Add(this.age1DisplayLabel);
            this.panel4.Controls.Add(this.address1DisplayLabel);
            this.panel4.Controls.Add(this.name1DisplayLabel);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.output1DisplayLabel);
            this.panel4.Controls.Add(this.output2DisplayLabel);
            this.panel4.Controls.Add(this.output3DisplayLabel);
            this.panel4.Controls.Add(this.output4DisplayLabel);
            this.panel4.Location = new System.Drawing.Point(12, 164);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(214, 172);
            this.panel4.TabIndex = 48;
            // 
            // phoneNumber1DisplayLabel
            // 
            this.phoneNumber1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneNumber1DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.phoneNumber1DisplayLabel.Name = "phoneNumber1DisplayLabel";
            this.phoneNumber1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.phoneNumber1DisplayLabel.TabIndex = 32;
            this.phoneNumber1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // age1DisplayLabel
            // 
            this.age1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.age1DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.age1DisplayLabel.Name = "age1DisplayLabel";
            this.age1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.age1DisplayLabel.TabIndex = 31;
            this.age1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // address1DisplayLabel
            // 
            this.address1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.address1DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.address1DisplayLabel.Name = "address1DisplayLabel";
            this.address1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.address1DisplayLabel.TabIndex = 30;
            this.address1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name1DisplayLabel
            // 
            this.name1DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name1DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name1DisplayLabel.Name = "name1DisplayLabel";
            this.name1DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name1DisplayLabel.TabIndex = 29;
            this.name1DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Person 1:";
            // 
            // output1DisplayLabel
            // 
            this.output1DisplayLabel.AutoSize = true;
            this.output1DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output1DisplayLabel.Name = "output1DisplayLabel";
            this.output1DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output1DisplayLabel.TabIndex = 20;
            this.output1DisplayLabel.Text = "Name:";
            // 
            // output2DisplayLabel
            // 
            this.output2DisplayLabel.AutoSize = true;
            this.output2DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output2DisplayLabel.Name = "output2DisplayLabel";
            this.output2DisplayLabel.Size = new System.Drawing.Size(48, 13);
            this.output2DisplayLabel.TabIndex = 21;
            this.output2DisplayLabel.Text = "Address:";
            // 
            // output3DisplayLabel
            // 
            this.output3DisplayLabel.AutoSize = true;
            this.output3DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output3DisplayLabel.Name = "output3DisplayLabel";
            this.output3DisplayLabel.Size = new System.Drawing.Size(29, 13);
            this.output3DisplayLabel.TabIndex = 22;
            this.output3DisplayLabel.Text = "Age:";
            // 
            // output4DisplayLabel
            // 
            this.output4DisplayLabel.AutoSize = true;
            this.output4DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output4DisplayLabel.Name = "output4DisplayLabel";
            this.output4DisplayLabel.Size = new System.Drawing.Size(81, 13);
            this.output4DisplayLabel.TabIndex = 26;
            this.output4DisplayLabel.Text = "Phone Number:";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.phoneNumber2DisplayLabel);
            this.panel5.Controls.Add(this.age2DisplayLabel);
            this.panel5.Controls.Add(this.address2DisplayLabel);
            this.panel5.Controls.Add(this.name2DisplayLabel);
            this.panel5.Controls.Add(this.label8);
            this.panel5.Controls.Add(this.output5DisplayLabel);
            this.panel5.Controls.Add(this.output6DisplayLabel);
            this.panel5.Controls.Add(this.output7DisplayLabel);
            this.panel5.Controls.Add(this.output8DisplayLabel);
            this.panel5.Location = new System.Drawing.Point(232, 164);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(214, 172);
            this.panel5.TabIndex = 49;
            // 
            // phoneNumber2DisplayLabel
            // 
            this.phoneNumber2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneNumber2DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.phoneNumber2DisplayLabel.Name = "phoneNumber2DisplayLabel";
            this.phoneNumber2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.phoneNumber2DisplayLabel.TabIndex = 32;
            this.phoneNumber2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // age2DisplayLabel
            // 
            this.age2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.age2DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.age2DisplayLabel.Name = "age2DisplayLabel";
            this.age2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.age2DisplayLabel.TabIndex = 31;
            this.age2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // address2DisplayLabel
            // 
            this.address2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.address2DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.address2DisplayLabel.Name = "address2DisplayLabel";
            this.address2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.address2DisplayLabel.TabIndex = 30;
            this.address2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name2DisplayLabel
            // 
            this.name2DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name2DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name2DisplayLabel.Name = "name2DisplayLabel";
            this.name2DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name2DisplayLabel.TabIndex = 29;
            this.name2DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Person 2:";
            // 
            // output5DisplayLabel
            // 
            this.output5DisplayLabel.AutoSize = true;
            this.output5DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output5DisplayLabel.Name = "output5DisplayLabel";
            this.output5DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output5DisplayLabel.TabIndex = 20;
            this.output5DisplayLabel.Text = "Name:";
            // 
            // output6DisplayLabel
            // 
            this.output6DisplayLabel.AutoSize = true;
            this.output6DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output6DisplayLabel.Name = "output6DisplayLabel";
            this.output6DisplayLabel.Size = new System.Drawing.Size(48, 13);
            this.output6DisplayLabel.TabIndex = 21;
            this.output6DisplayLabel.Text = "Address:";
            // 
            // output7DisplayLabel
            // 
            this.output7DisplayLabel.AutoSize = true;
            this.output7DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output7DisplayLabel.Name = "output7DisplayLabel";
            this.output7DisplayLabel.Size = new System.Drawing.Size(29, 13);
            this.output7DisplayLabel.TabIndex = 22;
            this.output7DisplayLabel.Text = "Age:";
            // 
            // output8DisplayLabel
            // 
            this.output8DisplayLabel.AutoSize = true;
            this.output8DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output8DisplayLabel.Name = "output8DisplayLabel";
            this.output8DisplayLabel.Size = new System.Drawing.Size(81, 13);
            this.output8DisplayLabel.TabIndex = 26;
            this.output8DisplayLabel.Text = "Phone Number:";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.phoneNumber3DisplayLabel);
            this.panel6.Controls.Add(this.age3DisplayLabel);
            this.panel6.Controls.Add(this.address3DisplayLabel);
            this.panel6.Controls.Add(this.name3DisplayLabel);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.output9DisplayLabel);
            this.panel6.Controls.Add(this.output10DisplayLabel);
            this.panel6.Controls.Add(this.output11DisplayLabel);
            this.panel6.Controls.Add(this.output12DisplayLabel);
            this.panel6.Location = new System.Drawing.Point(452, 164);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(214, 172);
            this.panel6.TabIndex = 50;
            // 
            // phoneNumber3DisplayLabel
            // 
            this.phoneNumber3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phoneNumber3DisplayLabel.Location = new System.Drawing.Point(95, 131);
            this.phoneNumber3DisplayLabel.Name = "phoneNumber3DisplayLabel";
            this.phoneNumber3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.phoneNumber3DisplayLabel.TabIndex = 32;
            this.phoneNumber3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // age3DisplayLabel
            // 
            this.age3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.age3DisplayLabel.Location = new System.Drawing.Point(95, 97);
            this.age3DisplayLabel.Name = "age3DisplayLabel";
            this.age3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.age3DisplayLabel.TabIndex = 31;
            this.age3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // address3DisplayLabel
            // 
            this.address3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.address3DisplayLabel.Location = new System.Drawing.Point(95, 65);
            this.address3DisplayLabel.Name = "address3DisplayLabel";
            this.address3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.address3DisplayLabel.TabIndex = 30;
            this.address3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // name3DisplayLabel
            // 
            this.name3DisplayLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name3DisplayLabel.Location = new System.Drawing.Point(95, 33);
            this.name3DisplayLabel.Name = "name3DisplayLabel";
            this.name3DisplayLabel.Size = new System.Drawing.Size(114, 25);
            this.name3DisplayLabel.TabIndex = 29;
            this.name3DisplayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(52, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Person 3:";
            // 
            // output9DisplayLabel
            // 
            this.output9DisplayLabel.AutoSize = true;
            this.output9DisplayLabel.Location = new System.Drawing.Point(11, 39);
            this.output9DisplayLabel.Name = "output9DisplayLabel";
            this.output9DisplayLabel.Size = new System.Drawing.Size(38, 13);
            this.output9DisplayLabel.TabIndex = 20;
            this.output9DisplayLabel.Text = "Name:";
            // 
            // output10DisplayLabel
            // 
            this.output10DisplayLabel.AutoSize = true;
            this.output10DisplayLabel.Location = new System.Drawing.Point(11, 71);
            this.output10DisplayLabel.Name = "output10DisplayLabel";
            this.output10DisplayLabel.Size = new System.Drawing.Size(48, 13);
            this.output10DisplayLabel.TabIndex = 21;
            this.output10DisplayLabel.Text = "Address:";
            // 
            // output11DisplayLabel
            // 
            this.output11DisplayLabel.AutoSize = true;
            this.output11DisplayLabel.Location = new System.Drawing.Point(11, 103);
            this.output11DisplayLabel.Name = "output11DisplayLabel";
            this.output11DisplayLabel.Size = new System.Drawing.Size(29, 13);
            this.output11DisplayLabel.TabIndex = 22;
            this.output11DisplayLabel.Text = "Age:";
            // 
            // output12DisplayLabel
            // 
            this.output12DisplayLabel.AutoSize = true;
            this.output12DisplayLabel.Location = new System.Drawing.Point(11, 137);
            this.output12DisplayLabel.Name = "output12DisplayLabel";
            this.output12DisplayLabel.Size = new System.Drawing.Size(81, 13);
            this.output12DisplayLabel.TabIndex = 26;
            this.output12DisplayLabel.Text = "Phone Number:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 410);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.createPersonButton);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox age1TextBox;
        private System.Windows.Forms.TextBox address1TextBox;
        private System.Windows.Forms.TextBox name1TextBox;
        private System.Windows.Forms.Label input3Label;
        private System.Windows.Forms.Label input2Label;
        private System.Windows.Forms.Label input1Label;
        private System.Windows.Forms.TextBox phoneNumber1TextBox;
        private System.Windows.Forms.Label input4Label;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button createPersonButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label object1Label;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label input5Label;
        private System.Windows.Forms.Label input6Label;
        private System.Windows.Forms.Label input7Label;
        private System.Windows.Forms.Label input8Label;
        private System.Windows.Forms.TextBox phoneNumber2TextBox;
        private System.Windows.Forms.TextBox age2TextBox;
        private System.Windows.Forms.TextBox address2TextBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label input9Label;
        private System.Windows.Forms.Label input10Label;
        private System.Windows.Forms.Label input11Label;
        private System.Windows.Forms.Label input12Label;
        private System.Windows.Forms.TextBox phoneNumber3TextBox;
        private System.Windows.Forms.TextBox age3TextBox;
        private System.Windows.Forms.TextBox address3TextBox;
        private System.Windows.Forms.TextBox name3TextBox;
        private System.Windows.Forms.TextBox name2TextBox;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label age1DisplayLabel;
        private System.Windows.Forms.Label address1DisplayLabel;
        private System.Windows.Forms.Label name1DisplayLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label output1DisplayLabel;
        private System.Windows.Forms.Label output2DisplayLabel;
        private System.Windows.Forms.Label output3DisplayLabel;
        private System.Windows.Forms.Label output4DisplayLabel;
        private System.Windows.Forms.Label phoneNumber1DisplayLabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label phoneNumber2DisplayLabel;
        private System.Windows.Forms.Label age2DisplayLabel;
        private System.Windows.Forms.Label address2DisplayLabel;
        private System.Windows.Forms.Label name2DisplayLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label output5DisplayLabel;
        private System.Windows.Forms.Label output6DisplayLabel;
        private System.Windows.Forms.Label output7DisplayLabel;
        private System.Windows.Forms.Label output8DisplayLabel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label phoneNumber3DisplayLabel;
        private System.Windows.Forms.Label age3DisplayLabel;
        private System.Windows.Forms.Label address3DisplayLabel;
        private System.Windows.Forms.Label name3DisplayLabel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label output9DisplayLabel;
        private System.Windows.Forms.Label output10DisplayLabel;
        private System.Windows.Forms.Label output11DisplayLabel;
        private System.Windows.Forms.Label output12DisplayLabel;
    }
}

